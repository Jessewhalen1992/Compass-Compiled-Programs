using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices;
using DrillNamer.UI;
using DrillNamer.Infrastructure;

namespace DrillNamer.Commands
{
    public static class DrillPropsCommands
    {
        private static FindReplaceForm _form;

        [CommandMethod("drillprops", CommandFlags.Session)]
        [CommandMethod("drillnames", CommandFlags.Session)]
        public static void ShowDrillProps()
        {
            Bootstrap.Init();
            if (_form != null && !_form.IsDisposed)
            {
                Application.ShowModelessDialog(_form);
                _form.BringToFront();
                return;
            }

            _form = new FindReplaceForm();
            _form.FormClosed += (s, e) => _form = null;
            Application.ShowModelessDialog(_form);
        }
    }
}
