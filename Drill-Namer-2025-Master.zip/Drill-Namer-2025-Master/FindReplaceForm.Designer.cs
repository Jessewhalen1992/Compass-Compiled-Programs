using System.Windows.Forms;

namespace DrillNamer.UI
{
    public partial class FindReplaceForm
    {
        private Button saveButton;
    }
}
