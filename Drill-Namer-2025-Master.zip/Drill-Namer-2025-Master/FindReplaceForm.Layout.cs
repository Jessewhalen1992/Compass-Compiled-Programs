using System;
using System.Windows.Forms;
using Autodesk.AutoCAD.ApplicationServices;
using System.Drawing;

namespace DrillNamer.UI
{
    public partial class FindReplaceForm
    {
        #region UI Fields
        // default to 12 drills like the legacy implementation
        private int DrillCount = 12;
        private TextBox[] drillTextBoxes;
        private Label[] drillLabels;
        private Button[] headingButtons;
        private Button[] setButtons;
        private Button[] resetButtons;
        private ComboBox headingComboBox;
        private Button updateFromAttributesButton;
        private ComboBox swapComboBox1;
        private ComboBox swapComboBox2;
        private Button swapButton;
        private Button headingAllButton;
        private Button setAllButton;
        private Button resetAllButton;
        private Button checkButton;
        private GroupBox drillGroupBox;
        private Document _boundDoc;   // owner DWG
        private Panel _lockOverlay;
        private System.ComponentModel.IContainer components = null;
        private ToolStripStatusLabel _activeDwgStatus;
        #endregion

        private void InitializeDynamicControls()
        {
            // Basic form settings
            // Let the user resize the window but show scrollbars when needed
            this.AutoScroll = true;
            this.AutoSize = false;
            this.BackColor = System.Drawing.Color.Black;
            this.ForeColor = System.Drawing.Color.White;
            this.Text = "DRILL PROPERTIES";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MinimumSize = new System.Drawing.Size(900, 600);

            // Arrays for dynamic controls
            drillTextBoxes = new TextBox[DrillCount];
            drillLabels = new Label[DrillCount];
            headingButtons = new Button[DrillCount];
            setButtons = new Button[DrillCount];
            resetButtons = new Button[DrillCount];

            // Example fonts
            var labelFont = new System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Bold);
            var textBoxFont = new System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Regular);
            var buttonFont = new System.Drawing.Font("Segoe UI", 8, System.Drawing.FontStyle.Bold);

            // Main scrolling panel
            Panel mainPanel = new Panel
            {
                Name = "mainPanel",
                AutoScroll = true,
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White,
                Dock = DockStyle.Fill
            };
            this.Controls.Add(mainPanel);

            // GroupBox for drill controls
            drillGroupBox = new GroupBox
            {
                Text = "Drill Controls",
                Location = new System.Drawing.Point(10, 10),
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Dock = DockStyle.Top,
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White,
                Padding = new Padding(10)
            };
            mainPanel.Controls.Add(drillGroupBox);

            // TableLayoutPanel for DRILL Label/Name/Heading/Set/Reset columns
            TableLayoutPanel tableLayout = new TableLayoutPanel
            {
                Location = new System.Drawing.Point(10, 20),
                ColumnCount = 5,
                RowCount = DrillCount + 1,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White,
                Dock = DockStyle.Top,
                Padding = new Padding(5)
            };

            // Give labels and names more room
            tableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));  // Drill Label
            tableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));  // Drill Name
            tableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 8F));   // HEADING (wider so text isn't cut off)
            tableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 6F));   // SET
            tableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 6F));   // RESET

            // Header row
            tableLayout.Controls.Add(new Label
            {
                Text = "Drill Label",
                Font = labelFont,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Dock = DockStyle.Fill,
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White
            }, 0, 0);
            tableLayout.Controls.Add(new Label
            {
                Text = "Drill Name",
                Font = labelFont,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Dock = DockStyle.Fill,
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White
            }, 1, 0);
            tableLayout.Controls.Add(new Label
            {
                Text = "HEADING",
                Font = labelFont,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Dock = DockStyle.Fill,
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White
            }, 2, 0);
            tableLayout.Controls.Add(new Label
            {
                Text = "SET",
                Font = labelFont,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Dock = DockStyle.Fill,
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White
            }, 3, 0);
            tableLayout.Controls.Add(new Label
            {
                Text = "RESET",
                Font = labelFont,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Dock = DockStyle.Fill,
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White
            }, 4, 0);

            // Populate drill rows
            for (int i = 0; i < DrillCount; i++)
            {
                // DRILL Label
                drillLabels[i] = new Label
                {
                    Text = $"DRILL_{i + 1}",
                    Font = labelFont,
                    TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                    Dock = DockStyle.Fill,
                    BackColor = System.Drawing.Color.Black,
                    ForeColor = System.Drawing.Color.White
                };
                tableLayout.Controls.Add(drillLabels[i], 0, i + 1);

                // DRILL TextBox
                drillTextBoxes[i] = new TextBox
                {
                    Font = textBoxFont,
                    Dock = DockStyle.Fill,
                    BackColor = System.Drawing.Color.Black,
                    ForeColor = System.Drawing.Color.White
                };
                tableLayout.Controls.Add(drillTextBoxes[i], 1, i + 1);

                // Let the textbox grow/shrink with the form
                drillTextBoxes[i].Anchor = AnchorStyles.Left | AnchorStyles.Right;
                drillTextBoxes[i].MaximumSize = new Size(0, 20);   // (0 = no horizontal limit)

                // HEADING button
                headingButtons[i] = new Button
                {
                    Text = "HEADING",
                    Font = buttonFont,
                    BackColor = System.Drawing.Color.DarkGreen,
                    ForeColor = System.Drawing.Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Dock = DockStyle.Fill
                };
                int rowIndex = i;
                headingButtons[i].Click += (sender, e) => HeadingButton_Click(rowIndex);
                tableLayout.Controls.Add(headingButtons[i], 2, i + 1);

                // SET button
                setButtons[i] = new Button
                {
                    Text = "SET",
                    Font = buttonFont,
                    BackColor = System.Drawing.Color.DarkCyan,
                    ForeColor = System.Drawing.Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Dock = DockStyle.Fill
                };
                setButtons[i].Click += (sender, e) => SetDrill(rowIndex);
                tableLayout.Controls.Add(setButtons[i], 3, i + 1);

                // RESET button
                resetButtons[i] = new Button
                {
                    Text = "RESET",
                    Font = buttonFont,
                    BackColor = System.Drawing.Color.DarkRed,
                    ForeColor = System.Drawing.Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Dock = DockStyle.Fill
                };
                resetButtons[i].Click += (sender, e) => ResetDrill(rowIndex);
                tableLayout.Controls.Add(resetButtons[i], 4, i + 1);
            }

            drillGroupBox.Controls.Add(tableLayout);
            int nextY = tableLayout.Bottom + 20;

            // Heading type ComboBox
            headingComboBox = new ComboBox()
            {
                Location = new System.Drawing.Point(10, nextY),
                Size = new System.Drawing.Size(150, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Regular),
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White
            };
            headingComboBox.Items.AddRange(new string[] { "ICP", "HEEL" });
            headingComboBox.SelectedIndex = 0;
            headingComboBox.SelectedIndexChanged += (sender, e) => SaveToJson();

            Label clientLabel = new Label()
            {
                Text = "ICP OR HEEL?",
                Font = new System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Bold),
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White,
                AutoSize = true,
                Location = new System.Drawing.Point(10, nextY)
            };
            int clientLabelWidth = TextRenderer.MeasureText(clientLabel.Text, clientLabel.Font).Width;
            headingComboBox.Location = new System.Drawing.Point(clientLabel.Location.X + clientLabelWidth + 10, nextY);

            drillGroupBox.Controls.Add(clientLabel);
            drillGroupBox.Controls.Add(headingComboBox);

            nextY = headingComboBox.Bottom + 20;

            // UPDATE FROM BLOCK ATTRIBUTE button
            updateFromAttributesButton = new Button()
            {
                Text = "UPDATE FROM BLOCK ATTRIBUTE",
                Location = new System.Drawing.Point(10, nextY),
                Size = new System.Drawing.Size(220, 30),
                Font = new System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Bold),
                BackColor = System.Drawing.Color.Gray,
                ForeColor = System.Drawing.Color.White,
                FlatStyle = FlatStyle.Flat
            };
            updateFromAttributesButton.Click += UpdateFromAttributesButton_Click;
            drillGroupBox.Controls.Add(updateFromAttributesButton);

            nextY = updateFromAttributesButton.Bottom + 20;

            // SWAP ComboBoxes
            swapComboBox1 = new ComboBox()
            {
                Location = new System.Drawing.Point(10, nextY),
                Size = new System.Drawing.Size(100, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Regular),
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White
            };
            swapComboBox2 = new ComboBox()
            {
                Location = new System.Drawing.Point(swapComboBox1.Right + 10, nextY),
                Size = new System.Drawing.Size(100, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Regular),
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White
            };
            for (int i = 0; i < DrillCount; i++)
            {
                swapComboBox1.Items.Add($"DRILL_{i + 1}");
                swapComboBox2.Items.Add($"DRILL_{i + 1}");
            }
            swapComboBox1.SelectedIndex = 0;
            swapComboBox2.SelectedIndex = 1;
            drillGroupBox.Controls.Add(swapComboBox1);
            drillGroupBox.Controls.Add(swapComboBox2);

            // SWAP button
            swapButton = new Button()
            {
                Text = "SWAP",
                Location = new System.Drawing.Point(swapComboBox2.Right + 10, nextY),
                Size = new System.Drawing.Size(75, 25),
                Font = new System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Bold),
                BackColor = System.Drawing.Color.Orange,
                ForeColor = System.Drawing.Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            swapButton.Click += SwapButton_Click;
            drillGroupBox.Controls.Add(swapButton);

            // Optional logo
            int logoHeight = 80;
            int logoWidth = 200;
            int swapBottom = swapButton.Top + swapButton.Height;
            int logoY = swapBottom - logoHeight;
            int logoX = swapButton.Right + 10;
            string logoPath = @"C:\AUTOCAD-SETUP\Lisp_2000\Drill Properties\CompassLogo.png";
            PictureBox logoPictureBox = new PictureBox()
            {
                Name = "logoPictureBox",
                Size = new System.Drawing.Size(logoWidth, logoHeight),
                Location = new System.Drawing.Point(logoX, logoY),
                SizeMode = PictureBoxSizeMode.Zoom,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                BackColor = System.Drawing.Color.Black
            };
            if (System.IO.File.Exists(logoPath))
            {
                logoPictureBox.Image = System.Drawing.Image.FromFile(logoPath);
            }
            else
            {
                _log?.Warn($"Logo not found at {logoPath}");
            }
            drillGroupBox.Controls.Add(logoPictureBox);
            logoPictureBox.BringToFront();

            // Bottom panel with vertical stacking (TopDown)
            FlowLayoutPanel bottomPanel = new FlowLayoutPanel()
            {
                FlowDirection = System.Windows.Forms.FlowDirection.TopDown,  // <-- Fully qualify
                WrapContents = false,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Location = new System.Drawing.Point(10, Math.Max(swapButton.Bottom, logoPictureBox.Bottom) + 15),
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White,
                Margin = new Padding(0, 10, 0, 0)
            };
            drillGroupBox.Controls.Add(bottomPanel);

            // ROW 1: SET ALL, RESET ALL
            FlowLayoutPanel row1 = new FlowLayoutPanel()
            {
                FlowDirection = System.Windows.Forms.FlowDirection.LeftToRight, // <-- Fully qualify
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink
            };
            setAllButton = new Button()
            {
                Text = "SET ALL",
                Size = new System.Drawing.Size(100, 30),
                Font = buttonFont,
                BackColor = System.Drawing.Color.DarkCyan,
                ForeColor = System.Drawing.Color.White,
                FlatStyle = FlatStyle.Flat
            };
            setAllButton.Click += SetAllButton_Click;
            row1.Controls.Add(setAllButton);

            resetAllButton = new Button()
            {
                Text = "RESET ALL",
                Size = new System.Drawing.Size(100, 30),
                Font = buttonFont,
                BackColor = System.Drawing.Color.DarkRed,
                ForeColor = System.Drawing.Color.White,
                FlatStyle = FlatStyle.Flat
            };
            resetAllButton.Click += ResetAllButton_Click;
            row1.Controls.Add(resetAllButton);

            bottomPanel.Controls.Add(row1);

            // ROW 2: CHECK, WELL CORNERS, HEADING ALL
            FlowLayoutPanel row2 = new FlowLayoutPanel()
            {
                FlowDirection = System.Windows.Forms.FlowDirection.LeftToRight, // <-- Fully qualify
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink
            };
            checkButton = new Button()
            {
                Text = "CHECK",
                Size = new System.Drawing.Size(100, 30),
                Font = buttonFont,
                BackColor = System.Drawing.Color.Yellow,
                ForeColor = System.Drawing.Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            checkButton.Click += CheckButton_Click;
            row2.Controls.Add(checkButton);

            Button wellCornersButton = new Button()
            {
                Text = "WELL CORNERS",
                Size = new System.Drawing.Size(120, 30),
                Font = buttonFont,
                BackColor = System.Drawing.Color.MediumPurple,
                ForeColor = System.Drawing.Color.White,
                FlatStyle = FlatStyle.Flat
            };
            wellCornersButton.Click += WellCornersButton_Click;
            row2.Controls.Add(wellCornersButton);

            headingAllButton = new Button()
            {
                Text = "HEADING ALL",
                Size = new System.Drawing.Size(100, 30),
                Font = buttonFont,
                BackColor = System.Drawing.Color.DarkGreen,
                ForeColor = System.Drawing.Color.White,
                FlatStyle = FlatStyle.Flat
            };
            headingAllButton.Click += HeadingAllButton_Click;
            row2.Controls.Add(headingAllButton);

            bottomPanel.Controls.Add(row2);

            // ROW 3: CREATE TABLE, CREATE XLS, COMPLETE CORDS
            FlowLayoutPanel row3 = new FlowLayoutPanel()
            {
                FlowDirection = System.Windows.Forms.FlowDirection.LeftToRight, // <-- Fully qualify
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink
            };
            Button createTableButton = new Button()
            {
                Text = "CREATE TABLE",
                Size = new System.Drawing.Size(120, 30),
                Font = new System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Bold),
                BackColor = System.Drawing.Color.LightPink,
                ForeColor = System.Drawing.Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            createTableButton.Click += CreateTableButton_Click;
            row3.Controls.Add(createTableButton);

            Button createXlsButton = new Button()
            {
                Text = "CREATE XLS",
                Size = new System.Drawing.Size(100, 30),
                Font = new System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Bold),
                BackColor = System.Drawing.Color.LightPink,
                ForeColor = System.Drawing.Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            createXlsButton.Click += CreateXlsButton_Click;
            row3.Controls.Add(createXlsButton);

            Button completeCordsButton = new Button()
            {
                Text = "COMPLETE CORDS",
                Size = new System.Drawing.Size(140, 30),
                Font = new System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Bold),
                BackColor = System.Drawing.Color.Orange,
                ForeColor = System.Drawing.Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            completeCordsButton.Click += CompleteCordsButton_Click;
            row3.Controls.Add(completeCordsButton);

            bottomPanel.Controls.Add(row3);

            // ROW 4: GET UTMS, ADD DRILL PTS
            FlowLayoutPanel row4 = new FlowLayoutPanel()
            {
                FlowDirection = System.Windows.Forms.FlowDirection.LeftToRight, // <-- Fully qualify
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink
            };
            Button getUtmsButton = new Button()
            {
                Text = "GET UTMS",
                Size = new System.Drawing.Size(100, 30),
                Font = buttonFont,
                BackColor = System.Drawing.Color.LightBlue,
                ForeColor = System.Drawing.Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            getUtmsButton.Click += GetUtmsButton_Click;
            row4.Controls.Add(getUtmsButton);

            Button addDrillPtsButton = new Button()
            {
                Text = "ADD DRILL PTS",
                Size = new System.Drawing.Size(120, 30),
                Font = buttonFont,
                BackColor = System.Drawing.Color.LightBlue,
                ForeColor = System.Drawing.Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            addDrillPtsButton.Click += AddDrillPtsButton_Click;
            row4.Controls.Add(addDrillPtsButton);

            Button addOffsetsButton = new Button()
            {
                Text = "ADD OFFSETS",
                Size = new System.Drawing.Size(120, 30),
                Font = buttonFont,
                BackColor = System.Drawing.Color.LightBlue,
                ForeColor = System.Drawing.Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            addOffsetsButton.Click += AddOffsetsButton_Click;
            row4.Controls.Add(addOffsetsButton);

            bottomPanel.Controls.Add(row4);

            // ROW 5: NEW: UPDATE OFFSETS
            FlowLayoutPanel row5 = new FlowLayoutPanel()
            {
                FlowDirection = System.Windows.Forms.FlowDirection.LeftToRight,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink
            };
            Button updateOffsetsButton = new Button()
            {
                Text = "UPDATE OFFSETS",
                Size = new System.Drawing.Size(140, 30),
                Font = buttonFont,
                BackColor = System.Drawing.Color.LightGreen,
                ForeColor = System.Drawing.Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            updateOffsetsButton.Click += UpdateOffsetsButton_Click;
            row5.Controls.Add(updateOffsetsButton);
            bottomPanel.Controls.Add(row5);

            // Status strip
            StatusStrip statusStrip = new StatusStrip()
            {
                BackColor = System.Drawing.Color.Black,
                ForeColor = System.Drawing.Color.White,
                Dock = DockStyle.Bottom
            };
            ToolStripStatusLabel statusLabel = new ToolStripStatusLabel()
            {
                Text = "Ready",
                Spring = true,
                ForeColor = System.Drawing.Color.White
            };
            statusStrip.Items.Add(statusLabel);
            drillGroupBox.Controls.Add(statusStrip);

            // Give the form a generous starting size
            this.ClientSize = new System.Drawing.Size(1600, 800);
            this.DoubleBuffered = true;
            _activeDwgStatus = new ToolStripStatusLabel()
            {
                Text = "Active Drawing: (none)",
                ForeColor = Color.LightGreen
            };
            statusStrip.Items.Add(_activeDwgStatus);
        }
    }
}
