﻿using System;
using System.Reflection;
using OfficeOpenXml;
using NLog;

namespace DrillNamer.UI.Services
{
    public static partial class EpplusCompat
    {
        private static readonly Logger Log = LogManager.GetCurrentClassLogger();

        public static void EnsureLicense()
        {
            try
            {
                var pkgType = typeof(ExcelPackage);
                var asm = pkgType.Assembly;

                // ── EPPlus 8+ via ExcelPackage.License ───────────────────────────────────
                var licenseProp = pkgType.GetProperty(
                    "License",
                    BindingFlags.Public | BindingFlags.Static);
                if (licenseProp != null)
                {
                    var licObj = licenseProp.GetValue(null);
                    if (licObj != null)
                    {
                        // Organization (preferred)
                        var orgMeth = licObj.GetType()
                                           .GetMethod("SetNonCommercialOrganization", new[] { typeof(string) });
                        if (orgMeth != null)
                        {
                            // Use your org name or just your user name:
                            orgMeth.Invoke(licObj, new object[] { Environment.UserName });
                            return;
                        }

                        // Personal fallback
                        var persMeth = licObj.GetType()
                                            .GetMethod("SetNonCommercialPersonal", new[] { typeof(string) });
                        if (persMeth != null)
                        {
                            persMeth.Invoke(licObj, new object[] { Environment.UserName });
                            return;
                        }
                    }
                }

                // ── EPPlus 6 style via ExcelPackage.License.SetLicense(LicenseContext) ──
                var enumType = asm.GetType("OfficeOpenXml.LicenseContext")
                            ?? asm.GetType("OfficeOpenXml.ExcelPackageLicenseContext");
                if (enumType != null)
                {
                    var licPropOld = pkgType.GetProperty(
                        "License",
                        BindingFlags.Public | BindingFlags.Static);
                    if (licPropOld != null)
                    {
                        var licContainer = licPropOld.GetValue(null);
                        var setMeth = licContainer?.GetType()
                                                   .GetMethod("SetLicense", new[] { enumType });
                        if (setMeth != null)
                        {
                            var nonComm = Enum.Parse(enumType, "NonCommercial");
                            setMeth.Invoke(licContainer, new object[] { nonComm });
                            return;
                        }
                    }
                }

                // ── EPPlus 5 style via ExcelPackage.LicenseContext ────────────────────────
                var ctxProp = pkgType.GetProperty(
                    "LicenseContext",
                    BindingFlags.Public | BindingFlags.Static);
                if (ctxProp != null)
                {
                    var nonComm = Enum.Parse(ctxProp.PropertyType, "NonCommercial");
                    ctxProp.SetValue(null, nonComm);
                    return;
                }

                // EPPlus ≤4.x has no licensing API – nothing to do
            }
            catch (Exception ex)
            {
                Log.Warn(ex, "Failed to set EPPlus license context");
            }
        }
    }
}
