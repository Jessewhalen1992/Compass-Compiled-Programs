using Xunit;
using DrillNamer.UI;

namespace DrillNamer.Tests
{
    public class FindReplaceFormTests
    {
        [Fact]
        public void Constructor_WithNullGridState_DoesNotThrow()
        {
            var exception = Record.Exception(() => new FindReplaceForm());
            Assert.Null(exception);
        }
    }
}
