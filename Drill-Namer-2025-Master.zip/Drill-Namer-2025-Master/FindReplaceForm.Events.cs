using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Diagnostics;
using System.Globalization;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using DrillNamer.UI.Services;
using DrillNamer.UI.Models;
using OfficeOpenXml;
using System.Drawing;
using AcApplication = Autodesk.AutoCAD.ApplicationServices.Application;

namespace DrillNamer.UI
{
    public partial class FindReplaceForm
    {
        private TextBox GetTextBox(int index)
        {
            return drillTextBoxes != null && index >= 0 && index < drillTextBoxes.Length
                ? drillTextBoxes[index]
                : null;
        }

        private Label GetLabel(int index)
        {
            return drillLabels != null && index >= 0 && index < drillLabels.Length
                ? drillLabels[index]
                : null;
        }

        /// <summary>
        /// Ensures EPPlus is licensed for non-commercial use across all
        /// supported EPPlus versions.
        /// </summary>
        private static void SetEpplusLicense()
        {
            // fully-qualified call ensures the compiler always finds it
            DrillNamer.UI.Services.EpplusCompat.EnsureLicense();
        }


        private void HookDrawingActivation()
        {
            _boundDoc = AcApplication.DocumentManager.MdiActiveDocument;
            if (_boundDoc != null)
                _boundDoc.CommandEnded += BoundDoc_CommandEnded;

            AcApplication.DocumentManager.DocumentActivated += DocumentManager_DocumentActivated;
            AcApplication.DocumentManager.DocumentToBeDestroyed += DocumentManager_DocumentToBeDestroyed;
            SetUiLocked(false);
            UpdateActiveDrawingStatus(_boundDoc);
        }

        private void UnhookDrawingActivation()
        {
            try
            {
                AcApplication.DocumentManager.DocumentActivated -= DocumentManager_DocumentActivated;
            }
            catch
            {
                // ignore failures during shutdown
            }

            try
            {
                AcApplication.DocumentManager.DocumentToBeDestroyed -= DocumentManager_DocumentToBeDestroyed;
            }
            catch
            {
                // ignore failures during shutdown
            }

            if (_boundDoc != null)
            {
                try
                {
                    _boundDoc.CommandEnded -= BoundDoc_CommandEnded;
                }
                catch
                {
                    // Document may already be disposed; ignore any failures
                }

                _boundDoc = null;
            }
        }

        private void DocumentManager_DocumentActivated(object sender, DocumentCollectionEventArgs e)
        {
            bool sameDwg = e.Document == _boundDoc;
            SetUiLocked(!sameDwg);
            UpdateActiveDrawingStatus(e.Document);
        }

        private void DocumentManager_DocumentToBeDestroyed(object sender, DocumentCollectionEventArgs e)
        {
            if (_boundDoc == null || e.Document != _boundDoc)
                return;

            // remove Autodesk event handlers immediately on the COM thread
            UnhookDrawingActivation();

            if (IsHandleCreated && !IsDisposed)
            {
                BeginInvoke(new Action(() =>
                {
                    if (IsHandleCreated && !IsDisposed)
                        Close();
                }));
            }
        }

        private void BoundDoc_CommandEnded(object sender, CommandEventArgs e)
        {
            string cmd = e?.GlobalCommandName;
            if (string.IsNullOrEmpty(cmd)) return;
            if (cmd.Equals("SAVEAS", StringComparison.OrdinalIgnoreCase) ||
                cmd.Equals("QSAVE", StringComparison.OrdinalIgnoreCase) ||
                cmd.Equals("SAVE", StringComparison.OrdinalIgnoreCase))
            {
                BeginInvoke(new Action(() => UpdateActiveDrawingStatus(_boundDoc)));
            }
        }
        private void UpdateActiveDrawingStatus(Document activeDoc)
        {
            if (_activeDwgStatus == null)
                return;

            if (InvokeRequired)
            {
                BeginInvoke(new Action(() => UpdateActiveDrawingStatus(activeDoc)));
                return;
            }

            var name = activeDoc != null && !string.IsNullOrEmpty(activeDoc.Name)
                ? System.IO.Path.GetFileName(activeDoc.Name)
                : "(none)";

            _activeDwgStatus.Text = $"Active Drawing: {name}";
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            UnhookDrawingActivation();
            base.OnFormClosed(e);
        }
        private void NotImplemented()
        {
            MessageBox.Show("This feature is not implemented in this build.", "Not Implemented", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void HeadingButton_Click(int index)
        {
            Document doc = AcApplication.DocumentManager.MdiActiveDocument;
            if (doc == null)
            {
                ShowAlert("No active AutoCAD document.");
                return;
            }
            using (DocumentLock docLock = doc.LockDocument())
            using (Transaction tr = doc.Database.TransactionManager.StartTransaction())
            {
                string drillName = GetLabel(index)?.Text.Trim() ?? string.Empty;
                string defaultName = $"DRILL_{index + 1}";

                _log.Info($"Initiating creation of DRILL and Heading blocks for {defaultName} with name '{drillName}'.");

                if (string.IsNullOrWhiteSpace(drillName))
                {
                    _log.Warn($"Drill name for {defaultName} is empty. Operation aborted.");
                    MessageBox.Show($"Drill name for {defaultName} cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _log.Info("Prompting user to select insertion point for DRILL block.");
                Editor ed = doc.Editor;
                PromptPointResult ppr1 = ed.GetPoint("\nSelect insertion point for DRILL block:");
                if (ppr1.Status != PromptStatus.OK)
                {
                    _log.Info("User canceled the selection of insertion point for DRILL block.");
                    return;
                }
                Point3d insertionPointDrill = ppr1.Value;

                ObjectId drillBlockId = AutoCADHelper.InsertBlock(
                    "DRILL",
                    insertionPointDrill,
                    new Dictionary<string, string> { { "DRILL", drillName } },
                    2.0);
                if (drillBlockId == ObjectId.Null)
                {
                    _log.Error("Failed to insert DRILL block.");
                    MessageBox.Show("Failed to insert DRILL block.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string selectedHeading = headingComboBox.SelectedItem?.ToString() ?? "ICP";
                _log.Info($"Prompting user to select insertion point for '{selectedHeading}' block.");
                PromptPointResult ppr2 = ed.GetPoint($"\nSelect insertion point for {selectedHeading} block:");
                if (ppr2.Status != PromptStatus.OK)
                {
                    _log.Info($"User canceled insertion for {selectedHeading} block.");
                    return;
                }
                Point3d insertionPointHeading = ppr2.Value;

                string headingBlockName = "DRILL HEADING";

                ObjectId headingBlockId = AutoCADHelper.InsertBlock(
                    headingBlockName,
                    insertionPointHeading,
                    new Dictionary<string, string> { { "DRILLNAME", drillName } },
                    1.0);
                if (headingBlockId == ObjectId.Null)
                {
                    _log.Error($"Failed to insert heading block '{headingBlockName}'.");
                    MessageBox.Show($"Failed to insert {headingBlockName} block.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                tr.Commit();
                _log.Info($"Successfully inserted DRILL and {headingBlockName} for {defaultName}.");
                MessageBox.Show($"Successfully inserted DRILL and {headingBlockName} blocks for {defaultName}.",
                                "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void UpdateFromAttributesButton_Click(object sender, EventArgs e)
        {
            Document doc = AcApplication.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;

            PromptSelectionResult sel = ed.GetSelection();
            if (sel.Status != PromptStatus.OK)
            {
                MessageBox.Show("No objects selected.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var blockSvc = new AutoCADBlockService();
            bool[] updated = new bool[DrillCount];

            using (doc.LockDocument())
            using (Transaction tr = doc.Database.TransactionManager.StartTransaction())
            {
                foreach (SelectedObject obj in sel.Value)
                {
                    if (obj == null) continue;
                    var br = tr.GetObject(obj.ObjectId, OpenMode.ForRead) as BlockReference;
                    if (br == null) continue;

                    for (int i = 0; i < DrillCount; i++)
                    {
                        string tag = $"DRILL_{i + 1}";
                        string val = blockSvc.GetAttributeValue(br, tag, tr);
                        if (!string.IsNullOrEmpty(val))
                        {
                            var tb = GetTextBox(i);
                            var lb = GetLabel(i);
                            if (tb != null) tb.Text = val;
                            if (lb != null) lb.Text = val;
                            updated[i] = true;
                        }
                    }
                }
                tr.Commit();
            }

            for (int i = 0; i < DrillCount; i++)
            {
                if (!updated[i])
                {
                    string def = $"DRILL_{i + 1}";
                    var tb = GetTextBox(i);
                    var lb = GetLabel(i);
                    if (tb != null) tb.Text = def;
                    if (lb != null) lb.Text = def;
                }
            }

            SaveToJson();
            MessageBox.Show("Form fields updated from block attributes.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void SwapButton_Click(object sender, EventArgs e)
        {
            int index1 = swapComboBox1.SelectedIndex;
            int index2 = swapComboBox2.SelectedIndex;

            if (index1 == index2)
            {
                MessageBox.Show("Please pick two different drills to swap.");
                return;
            }

            string text1 = GetTextBox(index1)?.Text.Trim() ?? string.Empty;
            string text2 = GetTextBox(index2)?.Text.Trim() ?? string.Empty;
            string label1 = GetLabel(index1)?.Text.Trim() ?? string.Empty;
            string label2 = GetLabel(index2)?.Text.Trim() ?? string.Empty;

            var tb1 = GetTextBox(index1);
            var tb2 = GetTextBox(index2);
            var lb1 = GetLabel(index1);
            var lb2 = GetLabel(index2);
            if (tb1 != null) tb1.Text = text2;
            if (tb2 != null) tb2.Text = text1;
            if (lb1 != null) lb1.Text = label2;
            if (lb2 != null) lb2.Text = label1;

            Document doc = AcApplication.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;

            using (doc.LockDocument())
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable;
                foreach (ObjectId btrId in bt)
                {
                    BlockTableRecord btr = null;
                    try { btr = tr.GetObject(btrId, OpenMode.ForRead) as BlockTableRecord; }
                    catch { continue; }
                    if (btr == null) continue;
                    foreach (ObjectId id in btr)
                    {
                        BlockReference br = tr.GetObject(id, OpenMode.ForWrite, false) as BlockReference;
                        if (br == null) continue;
                        SwapDrillAttribute(br, $"DRILL_{index1 + 1}", text2, db, tr);
                        SwapDrillAttribute(br, $"DRILL_{index2 + 1}", text1, db, tr);
                    }
                }
                tr.Commit();
            }

            SaveToJson();
            MessageBox.Show($"Swapped {text1} <-> {text2}", "Swap Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void WellCornersButton_Click(object sender, EventArgs e)
        {
            Document doc = AcApplication.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;

            try
            {
                PromptEntityOptions peo = new PromptEntityOptions("\nSelect a polygon (polyline):");
                peo.SetRejectMessage("\nOnly polylines are allowed.");
                peo.AddAllowedClass(typeof(Polyline), true);

                PromptEntityResult per = ed.GetEntity(peo);
                if (per.Status != PromptStatus.OK)
                {
                    ed.WriteMessage("\nSelection cancelled.");
                    return;
                }

                List<Point2d> vertices = new List<Point2d>();
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    Polyline poly = tr.GetObject(per.ObjectId, OpenMode.ForRead) as Polyline;
                    if (poly == null)
                    {
                        MessageBox.Show("Selected entity is not a valid polyline.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    int numVerts = poly.NumberOfVertices;
                    for (int i = 0; i < numVerts; i++)
                    {
                        vertices.Add(poly.GetPoint2dAt(i));
                    }
                    tr.Commit();
                }

                if (vertices.Count == 0)
                {
                    MessageBox.Show("No vertices found in the selected polygon.", "No Data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                PromptPointResult ppr = ed.GetPoint("\nSelect insertion point for the WELL CORNERS table:");
                if (ppr.Status != PromptStatus.OK)
                {
                    ed.WriteMessage("\nInsertion point cancelled.");
                    return;
                }
                Point3d insertionPoint = ppr.Value;

                using (DocumentLock docLock = doc.LockDocument())
                {
                    var layerSvc = new LayerService();
                    layerSvc.EnsureLayer(db, "CG-NOTES");
                    using (Transaction tr = db.TransactionManager.StartTransaction())
                    {
                        BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                        BlockTableRecord btr = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);

                        int rows = vertices.Count;
                        int cols = 2;
                        Table table = new Table();
                        table.TableStyle = GetTableStyleId(db, "induction Bend", tr);
                        table.SetSize(rows, cols);
                        table.Position = insertionPoint;
                        table.Layer = "CG-NOTES";

                        for (int c = 0; c < cols; c++)
                        {
                            table.Columns[c].Width = 89.41;
                        }

                        for (int r = 0; r < rows; r++)
                        {
                            table.Rows[r].Height = 25.0;
                            Point2d vert = vertices[r];
                            table.Cells[r, 0].TextString = vert.Y.ToString("F2");
                            table.Cells[r, 1].TextString = vert.X.ToString("F2");
                        }

                        btr.AppendEntity(table);
                        tr.AddNewlyCreatedDBObject(table, true);
                        table.GenerateLayout();
                        UnmergeAllCells(table);
                        table.GenerateLayout();
                        tr.Commit();
                    }
                    MessageBox.Show("WELL CORNERS table created successfully on CG-NOTES, with unmerged cells.",
                                    "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Error creating WELL CORNERS table: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void HeadingAllButton_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show(
                "Are you sure you want to insert heading blocks (and DRILL blocks) for all non-default drills?",
                "Confirm HEADING ALL", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirmResult != DialogResult.Yes)
            {
                return;
            }

            Document doc = AcApplication.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;

            PromptEntityOptions peo = new PromptEntityOptions("\nSelect the data-linked table containing 'SURFACE':");
            peo.SetRejectMessage("\nOnly table entities are allowed.");
            peo.AddAllowedClass(typeof(Table), true);

            PromptEntityResult per = ed.GetEntity(peo);
            if (per.Status != PromptStatus.OK)
            {
                ed.WriteMessage("\nTable selection cancelled.");
                return;
            }

            Table surfaceTable;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                surfaceTable = tr.GetObject(per.ObjectId, OpenMode.ForRead) as Table;
                tr.Commit();
            }

            if (surfaceTable == null)
            {
                MessageBox.Show("Selected entity is not a valid table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            List<(int row, int col)> surfaceCells = new List<(int row, int col)>();
            for (int r = 0; r < surfaceTable.Rows.Count; r++)
            {
                for (int c = 0; c < surfaceTable.Columns.Count; c++)
                {
                    string cellValue = surfaceTable.Cells[r, c].TextString.Trim().ToUpper();
                    if (cellValue.Contains("SURFACE"))
                    {
                        surfaceCells.Add((r, c));
                    }
                }
            }

            if (surfaceCells.Count == 0)
            {
                MessageBox.Show("No 'SURFACE' cells found in the selected table.", "No Data",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            List<string> nonDefaultDrills = new List<string>();
            for (int i = 0; i < DrillCount; i++)
            {
                string drillName = GetLabel(i)?.Text.Trim() ?? string.Empty;
                string defaultName = $"DRILL_{i + 1}";
                if (!string.IsNullOrWhiteSpace(drillName) &&
                    !drillName.Equals(defaultName, StringComparison.OrdinalIgnoreCase))
                {
                    nonDefaultDrills.Add(drillName);
                }
            }

            if (nonDefaultDrills.Count == 0)
            {
                MessageBox.Show("No non-default drills to insert blocks for.", "No Data",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (nonDefaultDrills.Count > surfaceCells.Count)
            {
                MessageBox.Show("Not enough SURFACE cells for all non-default drills.",
                                "Data Mismatch", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string headingBlockName = "DRILL HEADING";

            try
            {
                using (Transaction tr = AutoCADHelper.StartTransaction())
                {
                    for (int i = 0; i < nonDefaultDrills.Count; i++)
                    {
                        string drillName = nonDefaultDrills[i];
                        var (surfaceRow, surfaceCol) = surfaceCells[i];

                        Point3d nwCorner = GetCellNWCorner(surfaceTable, surfaceRow, surfaceCol);

                        ObjectId headingBlockId = AutoCADHelper.InsertBlock(
                            headingBlockName,
                            nwCorner,
                            new Dictionary<string, string> { { "DRILLNAME", drillName } },
                            1.0);
                        if (headingBlockId == ObjectId.Null)
                        {
                            MessageBox.Show($"Failed to insert {headingBlockName} for {drillName}.",
                                            "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            continue;
                        }

                        Point3d drillPoint = new Point3d(nwCorner.X - 50.0, nwCorner.Y, nwCorner.Z);
                        ObjectId drillBlockId = AutoCADHelper.InsertBlock(
                            "DRILL",
                            drillPoint,
                            new Dictionary<string, string> { { "DRILL", drillName } },
                            2.0);
                        if (drillBlockId == ObjectId.Null)
                        {
                            MessageBox.Show($"Failed to insert DRILL block for {drillName}.",
                                            "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            continue;
                        }
                    }
                    tr.Commit();
                }
                MessageBox.Show("Successfully created DRILL + HEADING blocks for all non-default drills.",
                                "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (System.Exception ex)
            {
                _log.Error($"Exception in HeadingAllButton_Click: {ex.Message}", ex);
                MessageBox.Show($"An error occurred while inserting heading blocks: {ex.Message}",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void CreateTableButton_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog
                {
                    Filter = "Excel Files (*.xlsx;*.xls)|*.xlsx;*.xls|All Files (*.*)|*.*",
                    Title = "Select Excel File"
                };
                if (ofd.ShowDialog() != DialogResult.OK)
                    return;
                string excelFilePath = ofd.FileName;

                string range = ShowInputDialog("Enter cell range (e.g. A1:L15):", "Cell Range", "A1:L15");
                if (string.IsNullOrWhiteSpace(range))
                    return;

                string[,] excelData = ReadExcelData(excelFilePath, range);
                if (excelData == null)
                {
                    MessageBox.Show("Failed to read Excel data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Document doc = AcApplication.DocumentManager.MdiActiveDocument;
                Editor ed = doc.Editor;
                PromptPointResult ppr = ed.GetPoint("\nSelect insertion point for the table:");
                if (ppr.Status != PromptStatus.OK)
                    return;
                Point3d insertionPoint = ppr.Value;

                string tableStyleName = "induction Bend";

                using (DocumentLock docLock = doc.LockDocument())
                {
                    var layerSvc = new LayerService();
                    layerSvc.EnsureLayer(doc.Database, "CG-NOTES");
                    InsertAndFormatTable(insertionPoint, excelData, tableStyleName);
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Error creating table: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void CreateXlsButton_Click(object sender, EventArgs e)
        {
            try
            {
                Document doc = AcApplication.DocumentManager.MdiActiveDocument;
                Editor ed = doc.Editor;
                Database db = doc.Database;

                PromptEntityOptions peo = new PromptEntityOptions("\nSelect the table to export to XLS:");
                peo.SetRejectMessage("\nOnly table entities are allowed.");
                peo.AddAllowedClass(typeof(Table), true);

                PromptEntityResult per = ed.GetEntity(peo);
                if (per.Status != PromptStatus.OK)
                {
                    ed.WriteMessage("\nXLS save cancelled.");
                    return;
                }

                Table selectedTable;
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    selectedTable = tr.GetObject(per.ObjectId, OpenMode.ForRead) as Table;
                    tr.Commit();
                }
                if (selectedTable == null)
                {
                    MessageBox.Show("The selected entity is not a valid table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                SaveFileDialog sfd = new SaveFileDialog
                {
                    Filter = "Excel Files (*.xlsx)|*.xlsx|All Files (*.*)|*.*",
                    Title = "Save XLS File",
                    FileName = "ExportedTable.xlsx"
                };

                if (sfd.ShowDialog() != DialogResult.OK)
                {
                    ed.WriteMessage("\nXLS save cancelled.");
                    return;
                }
                string excelFilePath = sfd.FileName;

                int rows = selectedTable.Rows.Count;
                int cols = selectedTable.Columns.Count;

                SetEpplusLicense();
                using (var package = new ExcelPackage())
                {
                    var ws = package.Workbook.Worksheets.Add("ExportedTable");

                    for (int r = 0; r < rows; r++)
                    {
                        for (int c = 0; c < cols; c++)
                        {
                            string cellValue = selectedTable.Cells[r, c].TextString.Trim();
                            ws.Cells[r + 1, c + 1].Value = cellValue;
                        }
                    }

                    if (cols >= 3)
                    {
                        ws.Column(1).Width = 15;
                        ws.Column(2).Width = 12;
                        ws.Column(3).Width = 12;
                        ws.Column(2).Style.Numberformat.Format = "0.00";
                        ws.Column(3).Style.Numberformat.Format = "0.00";
                    }

                    package.SaveAs(new FileInfo(excelFilePath));
                }

                MessageBox.Show($"XLS file created successfully at:\n{excelFilePath}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"An error occurred while creating XLS:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void CompleteCordsButton_Click(object sender, EventArgs e)
        {
            var doc = AcApplication.DocumentManager.MdiActiveDocument;
            if (doc == null)
            {
                ShowAlert("No active AutoCAD document.");
                return;
            }

            var confirmUtm = MessageBox.Show(
                "ARE YOU IN UTM?",
                "Complete CORDS",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (confirmUtm != DialogResult.Yes)
                return;
            try
            {
                SetEpplusLicense();

                var csv = DrillCsvPipeline();
                if (string.IsNullOrEmpty(csv)) return;

                var excelPath = RunCordsExe(csv);
                if (string.IsNullOrEmpty(excelPath)) return;

                var tableData = ReadExcel(excelPath);
                if (tableData == null) return;

                var headingValue = headingComboBox.SelectedItem?.ToString() ?? "ICP";
                AdjustTableForClient(tableData, headingValue);

                if (!InsertTablePipeline(tableData)) return;

                ShowAlert("Coordinate table created!");
                _log.Info("COMPLETE CORDS succeeded.");
                HeadingAllButton_Click(null, EventArgs.Empty);
            }
            catch (System.Exception ex)
            {
                _log.Error($"Error in COMPLETE CORDS: {ex.Message}", ex);
                ShowAlert($"Error in COMPLETE CORDS: {ex.Message}");
            }
        }

        private void GetUtmsButton_Click(object sender, EventArgs e)
        {
            Document doc = AcApplication.DocumentManager.MdiActiveDocument;
            if (doc == null)
            {
                ShowAlert("No active AutoCAD document.");
                return;
            }

            var confirmUtm = MessageBox.Show(
                "ARE YOU IN UTM?",
                "Get UTMs",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (confirmUtm != DialogResult.Yes)
                return;
            try
            {
                Database db = doc.Database;
                var gridData = new List<(string Label, double Northing, double Easting)>();

                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                    BlockTableRecord ms = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForRead);
                    foreach (ObjectId id in ms)
                    {
                        Entity ent = tr.GetObject(id, OpenMode.ForRead) as Entity;
                        if (ent != null && ent.Layer.Equals("Z-DRILL-POINT", StringComparison.OrdinalIgnoreCase))
                        {
                            if (ent is DBText dbText)
                            {
                                string textValue = dbText.TextString.Trim();
                                if (IsGridLabel(textValue))
                                    gridData.Add((textValue, dbText.Position.Y, dbText.Position.X));
                            }
                            else if (ent is MText mText)
                            {
                                string textValue = mText.Contents.Trim();
                                if (IsGridLabel(textValue))
                                    gridData.Add((textValue, mText.Location.Y, mText.Location.X));
                            }
                        }
                    }
                    tr.Commit();
                }

                gridData = gridData.OrderBy(x => x.Label, new NaturalStringComparer()).ToList();

                string cordsDir = @"C:\CORDS";
                Directory.CreateDirectory(cordsDir);
                string csvPath = Path.Combine(cordsDir, "CORDS.csv");
                using (StreamWriter sw = new StreamWriter(csvPath, false))
                {
                    sw.WriteLine("Label,Northing,Easting");
                    foreach (var pt in gridData)
                        sw.WriteLine($"{pt.Label},{pt.Northing},{pt.Easting}");
                }

                MessageBox.Show($"UTM CSV created successfully at:\n{csvPath}",
                    "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (System.Exception ex)
            {
                _log.Error($"Error in GetUtmsButton_Click: {ex.Message}", ex);
                MessageBox.Show($"Error generating UTMs CSV: {ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void AddDrillPtsButton_Click(object sender, EventArgs e)
        {
            try
            {
                string letter = ShowInputDialog("Enter letter for drill points:", "Add Drill Pts", "A");
                if (string.IsNullOrWhiteSpace(letter))
                {
                    MessageBox.Show("Letter cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Document doc = AcApplication.DocumentManager.MdiActiveDocument;
                Editor ed = doc.Editor;
                Database db = doc.Database;

                PromptEntityOptions peo = new PromptEntityOptions("\nSelect a polyline:");
                peo.SetRejectMessage("\nOnly polylines are allowed.");
                peo.AddAllowedClass(typeof(Polyline), false);

                PromptEntityResult per = ed.GetEntity(peo);
                if (per.Status != PromptStatus.OK)
                {
                    ed.WriteMessage("\nSelection cancelled.");
                    return;
                }

                using (doc.LockDocument())
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    var layerSvc = new LayerService();
                    layerSvc.EnsureLayer(db, "Z-DRILL-POINT");

                    Polyline pline = tr.GetObject(per.ObjectId, OpenMode.ForRead) as Polyline;
                    if (pline == null)
                    {
                        MessageBox.Show("Selected entity is not a polyline.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    int count = Math.Min(pline.NumberOfVertices, 150);
                    BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                    BlockTableRecord ms = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);

                    for (int i = 0; i < count; i++)
                    {
                        Point2d pt2d = pline.GetPoint2dAt(i);
                        Point3d pt3d = new Point3d(pt2d.X, pt2d.Y, 0.0);
                        string label = $"{letter}{i + 1}";

                        DBText dbt = new DBText
                        {
                            Position = pt3d,
                            Height = 2.0,
                            TextString = label,
                            Layer = "Z-DRILL-POINT",
                            ColorIndex = 7
                        };

                        ms.AppendEntity(dbt);
                        tr.AddNewlyCreatedDBObject(dbt, true);
                    }
                    tr.Commit();
                }
                MessageBox.Show("Drill points added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (System.Exception ex)
            {
                _log.Error($"Error in AddDrillPtsButton_Click: {ex.Message}", ex);
                MessageBox.Show($"Error: {ex.Message}", "Add Drill Pts", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void AddOffsetsButton_Click(object sender, EventArgs e)
        {
            try
            {
                Document doc = AcApplication.DocumentManager.MdiActiveDocument;
                if (doc == null)
                {
                    ShowAlert("No active AutoCAD document.");
                    return;
                }

                var confirmGround = MessageBox.Show(
                    "ARE YOU IN GROUND?",
                    "Add Offsets",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);
                if (confirmGround != DialogResult.Yes)
                    return;
                Database db = doc.Database;

                var textEnts = GetEntitiesOnLayer(
                    db, "Z-DRILL-POINT",
                    RXObject.GetClass(typeof(DBText)),
                    RXObject.GetClass(typeof(MText))).ToList();

                Regex gridRx = new Regex("^[A-Z][1-9][0-9]{0,2}$");
                var gridPts = new List<(string Label, Point3d Pt)>();

                foreach (var ent in textEnts)
                {
                    if (ent is DBText t && gridRx.IsMatch(t.TextString.Trim()))
                        gridPts.Add((t.TextString.Trim(), t.Position));
                    else if (ent is MText m && gridRx.IsMatch(m.Contents.Trim()))
                        gridPts.Add((m.Contents.Trim(), m.Location));
                }
                if (gridPts.Count == 0)
                {
                    ShowAlert("No Z-DRILL-POINT labels found.");
                    return;
                }

                var curveEnts = GetEntitiesOnLayer(
                    db, "L-SEC-HB",
                    RXObject.GetClass(typeof(Line)),
                    RXObject.GetClass(typeof(Polyline)),
                    RXObject.GetClass(typeof(Polyline2d)),
                    RXObject.GetClass(typeof(Polyline3d))).ToList();

                var curves = curveEnts.OfType<Curve>().ToList();
                if (curves.Count == 0)
                {
                    ShowAlert("No L-SEC-HB polylines/lines found.");
                    return;
                }

                var warnList = new List<string>();
                Tolerance tol = new Tolerance(1e-3, 1e-3);

                using (DocumentLock _ = doc.LockDocument())
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    var layerSvc = new LayerService();
                    layerSvc.EnsureLayer(db, "P-Drill-Offset");

                    BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                    BlockTableRecord ms = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);

                    bool OffsetLineExists(Point3d p1, Point3d p2)
                    {
                        foreach (ObjectId id in ms)
                        {
                            if (tr.GetObject(id, OpenMode.ForRead) is Line ln &&
                                ln.Layer.Equals("P-Drill-Offset", StringComparison.OrdinalIgnoreCase))
                            {
                                if ((ln.StartPoint.IsEqualTo(p1, tol) && ln.EndPoint.IsEqualTo(p2, tol)) ||
                                    (ln.StartPoint.IsEqualTo(p2, tol) && ln.EndPoint.IsEqualTo(p1, tol)))
                                    return true;
                            }
                        }
                        return false;
                    }

                    void DrawOffset(Point3d from, Point3d to)
                    {
                        if (OffsetLineExists(from, to)) return;

                        double dist = from.DistanceTo(to);
                        string distStr = dist.ToString("0.0", CultureInfo.InvariantCulture);

                        var ln = new Line(from, to) { Layer = "P-Drill-Offset" };
                        ms.AppendEntity(ln);
                        tr.AddNewlyCreatedDBObject(ln, true);

                        Point3d mid = new Point3d((from.X + to.X) / 2.0,
                                                  (from.Y + to.Y) / 2.0,
                                                  (from.Z + to.Z) / 2.0);

                        var mt = new MText
                        {
                            Location = mid,
                            TextHeight = 2.5,
                            Contents = $"{{\\C1;{distStr}}}",
                            Layer = "P-Drill-Offset"
                        };
                        ms.AppendEntity(mt);
                        tr.AddNewlyCreatedDBObject(mt, true);

                        AcApplication.DocumentManager.MdiActiveDocument
                            .SendStringToExecute("DIMPERP ", true, false, false);
                    }

                    foreach (var (label, pt) in gridPts)
                    {
                        Curve nsCv = null, ewCv = null;
                        Point3d nsCp = Point3d.Origin, ewCp = Point3d.Origin;
                        double nsDx = double.MaxValue, ewDy = double.MaxValue;

                        foreach (var cv in curves)
                        {
                            Point3d cp = cv.GetClosestPointTo(pt, false);
                            double dst = pt.DistanceTo(cp);
                            if (dst > 830.0) continue;

                            double dx = Math.Abs(pt.X - cp.X);
                            double dy = Math.Abs(pt.Y - cp.Y);

                            if (dx < nsDx) { nsDx = dx; nsCv = cv; nsCp = cp; }
                            if (dy < ewDy) { ewDy = dy; ewCv = cv; ewCp = cp; }
                        }

                        bool nsMade = false, ewMade = false;
                        if (nsCv != null) { DrawOffset(pt, nsCp); nsMade = true; }
                        if (ewCv != null) { DrawOffset(pt, ewCp); ewMade = true; }

                        if (!nsMade) warnList.Add($"{label} (N-S)");
                        if (!ewMade) warnList.Add($"{label} (E-W)");
                    }

                    tr.Commit();
                }

                if (warnList.Count > 0)
                    ShowAlert("Unable to find L-SEC-HB for:\n  • " + string.Join("\n  • ", warnList));
                else
                    ShowAlert("Add Offsets complete.");
            }
            catch (System.Exception ex)
            {
                _log.Error($"AddOffsetsButton_Click: {ex.Message}", ex);
                ShowAlert($"Error: {ex.Message}");
            }
        }

        private void UpdateOffsetsButton_Click(object sender, EventArgs e)
        {
            try
            {
                _log.Info("Update Offsets: operation started.");

                Document doc = AcApplication.DocumentManager.MdiActiveDocument;
                if (doc == null)
                {
                    MessageBox.Show("No active AutoCAD document.", "Update Offsets",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                Editor ed = doc.Editor;
                Database db = doc.Database;

                PromptEntityOptions peo = new PromptEntityOptions("\nSelect the table to update offsets:");
                peo.SetRejectMessage("\n**Error:** Only table entities are allowed.");
                peo.AddAllowedClass(typeof(Table), exactMatch: true);
                PromptEntityResult per = ed.GetEntity(peo);
                if (per.Status != PromptStatus.OK)
                {
                    ed.WriteMessage("\nUpdate Offsets canceled by user.\n");
                    return;
                }

                using (DocumentLock docLock = doc.LockDocument())
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    Table table = tr.GetObject(per.ObjectId, OpenMode.ForRead) as Table;
                    if (table == null)
                    {
                        MessageBox.Show("The selected entity is not a table.", "Update Offsets",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    int[] columnsToCheck = { 2, 3 };
                    var dataCells = new List<(int row, int col, double originalVal, string direction, string originalText)>();
                    Regex offsetRegex = new Regex(@"^\s*([+-]?\d+(\.\d+)?)\s*([NnSsEeWw])\s*$");

                    for (int r = 0; r < table.Rows.Count; r++)
                    {
                        foreach (int colIndex in columnsToCheck)
                        {
                            string cellText = table.Cells[r, colIndex].TextString?.Trim() ?? string.Empty;
                            if (string.IsNullOrWhiteSpace(cellText)) continue;

                            Match match = offsetRegex.Match(cellText);
                            if (match.Success)
                            {
                                string numericStr = match.Groups[1].Value;
                                string direction = match.Groups[3].Value.ToUpper();
                                if (double.TryParse(numericStr, NumberStyles.Any, CultureInfo.InvariantCulture, out double originalVal))
                                    dataCells.Add((r, colIndex, originalVal, direction, cellText));
                            }
                        }
                    }

                    if (dataCells.Count == 0)
                    {
                        MessageBox.Show("No numeric offset values found in columns C or D of the selected table.",
                                        "Update Offsets", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        _log.Info("Update Offsets: No data found in columns C/D.");
                        return;
                    }

                    BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                    BlockTableRecord ms = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForRead);
                    var offsetTextIds = new List<ObjectId>();

                    foreach (ObjectId entId in ms)
                    {
                        Entity ent = tr.GetObject(entId, OpenMode.ForRead) as Entity;
                        if (ent == null) continue;

                        if (ent.Layer.Equals("P-Drill-Offset", StringComparison.OrdinalIgnoreCase)
                            && (ent is DBText || ent is MText))
                            offsetTextIds.Add(entId);
                    }

                    int textCount = offsetTextIds.Count;
                    if (textCount == 0)
                    {
                        MessageBox.Show("No offset text found on layer \"P-Drill-Offset\".",
                                        "Update Offsets", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        _log.Info("No text objects on layer P-Drill-Offset.");
                        return;
                    }

                    int dataCellCount = dataCells.Count;
                    if (textCount > dataCellCount)
                    {
                        ed.SetImpliedSelection(offsetTextIds.ToArray());
                        ed.WriteMessage($"\n**Warning:** Found {textCount} offset text objects for only {dataCellCount} table entries. All offset texts have been selected. Please review and try again.\n");
                        _log.Warn($"Update Offsets aborted: {textCount} offset texts for {dataCellCount} table cells.");
                        return;
                    }

                    List<(double value, ObjectId id)> offsetValues = new List<(double, ObjectId)>();
                    foreach (ObjectId tid in offsetTextIds)
                    {
                        Entity ent = tr.GetObject(tid, OpenMode.ForRead) as Entity;
                        if (ent is DBText dbText)
                        {
                            string txt = dbText.TextString.Trim();
                            _log.Info($"DBText => '{txt}'");
                            if (double.TryParse(txt, NumberStyles.Any, CultureInfo.InvariantCulture, out double val))
                                offsetValues.Add((val, tid));
                        }
                        else if (ent is MText mText)
                        {
                            string raw = mText.Contents;
                            _log.Info($"Raw MText.Contents => '{raw}'");

                            string plain = Regex.Replace(raw, @"\{\\[^\}]+;([^\}]+)\}", "$1");
                            plain = Regex.Replace(plain, @"\\[a-zA-Z]+\s*", " ");
                            plain = plain.Trim();
                            _log.Info($"Cleaned MText => '{plain}'");

                            string[] lines = plain.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                            bool foundNumeric = false;
                            foreach (string line in lines)
                            {
                                string candidate = line.Trim();
                                if (double.TryParse(candidate, NumberStyles.Any, CultureInfo.InvariantCulture, out double val))
                                {
                                    offsetValues.Add((val, tid));
                                    foundNumeric = true;
                                    break;
                                }
                                else
                                {
                                    Match m = Regex.Match(candidate, @"([+-]?\d+(\.\d+)?)");
                                    if (m.Success && double.TryParse(m.Groups[1].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out double extractedVal))
                                    {
                                        offsetValues.Add((extractedVal, tid));
                                        foundNumeric = true;
                                        break;
                                    }
                                }
                            }
                            if (!foundNumeric)
                                _log.Info("No numeric value found in MText => skipping.");
                        }
                    }

                    if (offsetValues.Count == 0)
                    {
                        MessageBox.Show("Text found on \"P-Drill-Offset\" layer, but none contained valid numeric values.",
                                        "Update Offsets", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        _log.Info("No numeric values in offset text objects.");
                        return;
                    }

                    double tolerance = 10.0;
                    int updatedCount = 0;
                    int noMatchCount = 0;
                    table.UpgradeOpen();

                    foreach (var cellInfo in dataCells)
                    {
                        double bestDiff = double.MaxValue;
                        int bestIndex = -1;

                        for (int i = 0; i < offsetValues.Count; i++)
                        {
                            double candidateVal = offsetValues[i].value;
                            double diff = Math.Abs(candidateVal - cellInfo.originalVal);
                            if (diff < bestDiff)
                            {
                                bestDiff = diff;
                                bestIndex = i;
                            }
                        }

                        if (bestIndex != -1 && bestDiff <= tolerance)
                        {
                            double matchedVal = offsetValues[bestIndex].value;
                            offsetValues.RemoveAt(bestIndex);

                            string newText = matchedVal.ToString("F1", CultureInfo.InvariantCulture) + " " + cellInfo.direction;
                            table.Cells[cellInfo.row, cellInfo.col].TextString = newText;
                            updatedCount++;
                        }
                        else
                        {
                            table.Cells[cellInfo.row, cellInfo.col].TextString = cellInfo.originalText;
                            table.Cells[cellInfo.row, cellInfo.col].BackgroundColor = Autodesk.AutoCAD.Colors.Color.FromColor(System.Drawing.Color.Red);
                            noMatchCount++;
                        }
                    }

                    table.GenerateLayout();
                    tr.Commit();

                    ed.WriteMessage($"\nUpdate Offsets completed: {updatedCount} cells updated, {noMatchCount} cells with no match.\n");
                    _log.Info($"Update Offsets done => {updatedCount} updated, {noMatchCount} no-match cells.");
                }
            }
            catch (System.Exception ex)
            {
                _log.Error($"Error in UpdateOffsetsButton_Click: {ex.Message}", ex);
                MessageBox.Show($"An error occurred: {ex.Message}", "Update Offsets",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SetDrill(int index, bool showMessage = true)
        {
            string defaultName = GetDefaultDrillName(index);
            string newDrillName = GetTextBox(index)?.Text.Trim() ?? string.Empty;
            string oldDrillName = GetLabel(index)?.Text.Trim() ?? string.Empty;
            _log.Info($"SetDrill => from '{oldDrillName}' to '{newDrillName}' (Tag='{defaultName}').");

            Document doc = AcApplication.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            try
            {
                using (DocumentLock dlock = doc.LockDocument())
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
                    const string targetLayer = "CG-NOTES";
                    if (lt.Has(targetLayer))
                    {
                        var ltr = (LayerTableRecord)tr.GetObject(lt[targetLayer], OpenMode.ForWrite);
                        if (ltr.IsLocked) ltr.IsLocked = false;
                    }

                    string newValue = newDrillName;
                    BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                    int updatedBlocks = 0;
                    foreach (ObjectId btrId in bt)
                    {
                        BlockTableRecord btr = null;
                        try { btr = tr.GetObject(btrId, OpenMode.ForRead) as BlockTableRecord; }
                        catch { continue; }
                        if (btr == null || btr.IsErased) continue;

                        foreach (ObjectId entId in btr)
                        {
                            Entity ent;
                            try { ent = tr.GetObject(entId, OpenMode.ForWrite, false) as Entity; }
                            catch { continue; }
                            if (ent == null || ent.IsErased) continue;

                            if (ent is BlockReference blockRef)
                            {
                                foreach (ObjectId attId in blockRef.AttributeCollection)
                                {
                                    AttributeReference attRef;
                                    try { attRef = tr.GetObject(attId, OpenMode.ForWrite, false) as AttributeReference; }
                                    catch { continue; }
                                    if (attRef == null || attRef.IsErased) continue;

                                    if (attRef.Tag.Equals(defaultName, StringComparison.OrdinalIgnoreCase))
                                    {
                                        _log.Info($"SetDrill => Setting '{attRef.Tag}' from '{attRef.TextString}' to '{newValue}'.");
                                        attRef.TextString = newValue;
                                        updatedBlocks++;
                                    }
                                }
                            }
                        }
                    }
                    tr.Commit();

                    if (updatedBlocks > 0)
                    {
                        _log.Info($"SetDrill => updated {updatedBlocks} attribute(s) for {defaultName}.");
                        if (showMessage)
                            MessageBox.Show($"Updated {updatedBlocks} attribute(s) for {defaultName}.", "Set Drill", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        _log.Warn($"No DRILL_x attributes found for {defaultName} to update.");
                        if (showMessage)
                            MessageBox.Show($"No DRILL_x attributes found for {defaultName} to update.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }

                UpdateAttributesWithMatchingValue(oldDrillName, newDrillName);
                var lbSet = GetLabel(index);
                if (lbSet != null) lbSet.Text = newDrillName;
                SaveToJson();
            }
            catch (Autodesk.AutoCAD.Runtime.Exception acadEx)
            {
                _log.Error($"AutoCAD error setting {defaultName}: {acadEx.ErrorStatus} - {acadEx.Message}", acadEx);
                MessageBox.Show($"AutoCAD error while setting drill attributes: {acadEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (System.Exception ex)
            {
                _log.Error($"Error setting {defaultName}: {ex.Message}", ex);
                MessageBox.Show($"An error occurred while setting drill attributes: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ResetDrill(int index)
        {
            Document doc = AcApplication.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;

            string defaultName = $"DRILL_{index + 1}";
            string newValue = (index == 0) ? defaultName : string.Empty;

            using (DocumentLock docLock = doc.LockDocument())
            {
                try
                {
                    using (Transaction tr = db.TransactionManager.StartTransaction())
                    {
                        BlockTable bt = null;
                        try { bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable; }
                        catch { return; }
                        if (bt == null) return;

                        int updatedAttributes = 0;

                        foreach (ObjectId btrId in bt)
                        {
                            BlockTableRecord btr = null;
                            try { btr = tr.GetObject(btrId, OpenMode.ForRead) as BlockTableRecord; }
                            catch { continue; }
                            if (btr == null || btr.IsErased) continue;

                            foreach (ObjectId entId in btr)
                            {
                                Entity ent = null;
                                try { ent = tr.GetObject(entId, OpenMode.ForWrite, false) as Entity; }
                                catch { continue; }
                                if (ent == null || ent.IsErased) continue;

                                if (ent is BlockReference blockRef)
                                {
                                    foreach (ObjectId attId in blockRef.AttributeCollection)
                                    {
                                        AttributeReference attRef = null;
                                        try { attRef = tr.GetObject(attId, OpenMode.ForWrite, false) as AttributeReference; }
                                        catch { continue; }
                                        if (attRef == null || attRef.IsErased) continue;

                                        if (attRef.Tag.Equals(defaultName, StringComparison.OrdinalIgnoreCase))
                                        {
                                            attRef.TextString = newValue;
                                            updatedAttributes++;
                                        }
                                    }
                                }

                                if (ent is MText mText)
                                {
                                    string oldName = GetTextBox(index)?.Text.Trim() ?? string.Empty;
                                    if (!string.IsNullOrEmpty(oldName) && mText.Contents.Contains(oldName))
                                    {
                                        mText.Contents = mText.Contents.Replace(oldName, defaultName);
                                        updatedAttributes++;
                                    }
                                }
                            }
                        }
                        tr.Commit();
                        _log.Info($"ResetDrill => updated {updatedAttributes} attributes.");
                    }
                }
                catch (System.Exception ex)
                {
                    _log.Error($"Error in ResetDrill: {ex.Message}", ex);
                    MessageBox.Show($"Error: {ex.Message}", "Reset Drill", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            var tbReset = GetTextBox(index);
            var lbReset = GetLabel(index);
            if (tbReset != null) tbReset.Text = newValue;
            if (lbReset != null) lbReset.Text = defaultName;
            SaveToJson();

            MessageBox.Show($"Successfully reset {defaultName}.", "Reset Drill", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void SaveToJson() => _presenter.Save();

        private void SetAllButton_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show(
                "Are you sure you want to set DRILLNAME for all drills?",
                "Confirm SET ALL", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirmResult != DialogResult.Yes)
            {
                _log.Info("Set All operation canceled by the user.");
                return;
            }

            List<string> changes = new List<string>();
            int updatedCount = 0;
            for (int i = 0; i < DrillCount; i++)
            {
                string drillName = GetTextBox(i)?.Text.Trim() ?? string.Empty;
                string defaultName = GetDefaultDrillName(i);
                bool isDefault = string.Equals(drillName, defaultName, StringComparison.OrdinalIgnoreCase);
                if (!isDefault || i == 0)
                {
                    string oldName = GetLabel(i)?.Text.Trim() ?? string.Empty;
                    if (!string.Equals(oldName, drillName, StringComparison.OrdinalIgnoreCase))
                    {
                        changes.Add($"{defaultName}: '{oldName}' -> '{drillName}'");
                    }
                    SetDrill(i, false);
                    updatedCount++;
                }
            }

            SaveToJson();
            _log.Info($"Set All operation completed. Total drills updated: {updatedCount}.");
            string summary = changes.Count > 0 ? string.Join("\n", changes) : "No changes were necessary.";
            MessageBox.Show(summary, "Set All", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ResetAllButton_Click(object sender, EventArgs e)
        {
            _log.Info("Initiating Reset All operation.");
            int totalReset = 0;

            Document doc = AcApplication.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;

            try
            {
                using (DocumentLock docLock = doc.LockDocument())
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    BlockTable bt = null;
                    try { bt = tr.GetObject(db.BlockTableId, OpenMode.ForRead) as BlockTable; }
                    catch { return; }
                    if (bt == null) return;

                    foreach (ObjectId btrId in bt)
                    {
                        BlockTableRecord btr = null;
                        try { btr = tr.GetObject(btrId, OpenMode.ForRead) as BlockTableRecord; }
                        catch { continue; }
                        if (btr == null || btr.IsErased) continue;

                        btr.UpgradeOpen();

                        foreach (ObjectId entId in btr)
                        {
                            Entity ent = null;
                            try { ent = tr.GetObject(entId, OpenMode.ForWrite, false) as Entity; }
                            catch { continue; }
                            if (ent == null || ent.IsErased) continue;

                            if (ent is BlockReference blockRef)
                            {
                                for (int i = 0; i < DrillCount; i++)
                                {
                                    string defaultName = $"DRILL_{i + 1}";
                                    string newValue = (i == 0) ? defaultName : string.Empty;

                                    foreach (ObjectId attId in blockRef.AttributeCollection)
                                    {
                                        AttributeReference attRef = null;
                                        try { attRef = tr.GetObject(attId, OpenMode.ForWrite, false) as AttributeReference; }
                                        catch { continue; }
                                        if (attRef == null || attRef.IsErased) continue;

                                        if (attRef.Tag.Equals(defaultName, StringComparison.OrdinalIgnoreCase))
                                        {
                                            _log.Info($"Resetting '{attRef.Tag}' from '{attRef.TextString}' to '{newValue}'.");
                                            attRef.TextString = newValue;
                                            totalReset++;
                                        }
                                    }
                                }
                            }

                            if (ent is MText mText)
                            {
                                for (int i = 0; i < DrillCount; i++)
                                {
                                    string defaultName = $"DRILL_{i + 1}";
                                    string currentText = GetTextBox(i)?.Text.Trim() ?? string.Empty;
                                    string newValue = (i == 0) ? defaultName : string.Empty;

                                    if (!string.IsNullOrEmpty(currentText) && mText.Contents.Contains(currentText))
                                    {
                                        _log.Info($"Resetting MText from '{mText.Contents}' to '{newValue}' (Handle={mText.Handle}).");
                                        mText.Contents = mText.Contents.Replace(currentText, defaultName);
                                        totalReset++;
                                    }
                                }
                            }
                        }
                    }
                    tr.Commit();
                }

                for (int i = 0; i < DrillCount; i++)
                {
                    string defaultName = $"DRILL_{i + 1}";
                    var tb = GetTextBox(i);
                    var lb = GetLabel(i);
                    if (tb != null) tb.Text = (i == 0) ? defaultName : string.Empty;
                    if (lb != null) lb.Text = defaultName;
                }

                SaveToJson();

                _log.Info($"Reset All completed. {totalReset} attributes reset.");
                MessageBox.Show($"Successfully reset all drills. Total attributes reset: {totalReset}.",
                                "Reset All", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (System.Exception ex)
            {
                _log.Error($"Error during Reset All: {ex.Message}", ex);
                MessageBox.Show($"An error occurred during the Reset All operation: {ex.Message}",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string GetDefaultDrillName(int index)
        {
            return $"DRILL_{index + 1}";
        }

        private void UpdateAttributesWithMatchingValue(string oldValue, string newValue)
        {
            string oldValTrim = oldValue?.Trim();
            string newValTrim = newValue?.Trim();

            // fully qualify Application to avoid ambiguity with System.Windows.Forms.Application
            Document acDoc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            Database db = acDoc.Database;

            int updatedCount = 0;
            using (DocumentLock docLock = acDoc.LockDocument())
            {
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                    foreach (ObjectId btrId in bt)
                    {
                        // open each block table record
                        BlockTableRecord btr;
                        try { btr = (BlockTableRecord)tr.GetObject(btrId, OpenMode.ForRead); }
                        catch { continue; }
                        if (btr == null || btr.IsErased) continue;

                        foreach (ObjectId entId in btr)
                        {
                            Entity ent = null;
                            // attempt to open the entity for write
                            try { ent = (Entity)tr.GetObject(entId, OpenMode.ForWrite, false); }
                            catch (Autodesk.AutoCAD.Runtime.Exception ex)
                            {
                                // handle locked layers and erased entities
                                if (ex.ErrorStatus == ErrorStatus.OnLockedLayer)
                                    ent = (Entity)db.TransactionManager.GetObject(entId, OpenMode.ForWrite, false, true);
                                else if (ex.ErrorStatus == ErrorStatus.WasErased)
                                    continue;
                                else
                                    throw;
                            }
                            if (ent == null || ent.IsErased) continue;

                            // update block attributes
                            if (ent is BlockReference blockRef)
                            {
                                foreach (ObjectId attId in blockRef.AttributeCollection)
                                {
                                    AttributeReference attRef = null;
                                    try { attRef = (AttributeReference)tr.GetObject(attId, OpenMode.ForWrite, false); }
                                    catch (Autodesk.AutoCAD.Runtime.Exception ex)
                                    {
                                        if (ex.ErrorStatus == ErrorStatus.OnLockedLayer)
                                            attRef = (AttributeReference)db.TransactionManager.GetObject(attId, OpenMode.ForWrite, false, true);
                                        else if (ex.ErrorStatus == ErrorStatus.WasErased)
                                            attRef = null;
                                        else
                                            throw;
                                    }
                                    // skip erased or null attributes
                                    if (attRef == null || attRef.IsErased) continue;

                                    // compare and update text
                                    if (attRef.TextString.Trim().Equals(oldValTrim, StringComparison.OrdinalIgnoreCase))
                                    {
                                        attRef.TextString = newValTrim;
                                        updatedCount++;
                                    }
                                }
                            }
                            // update DBText
                            else if (ent is DBText dbText)
                            {
                                if (dbText.TextString.Trim().Equals(oldValTrim, StringComparison.OrdinalIgnoreCase))
                                {
                                    dbText.TextString = newValTrim;
                                    updatedCount++;
                                }
                            }
                            // update MText
                            else if (ent is MText mText)
                            {
                                if (mText.Contents.Trim().Equals(oldValTrim, StringComparison.OrdinalIgnoreCase))
                                {
                                    mText.Contents = newValTrim;
                                    updatedCount++;
                                }
                            }
                        }
                    }
                    tr.Commit();
                }
            }

            // updatedCount now reflects how many attributes/texts were changed
            // You can log or display this value as appropriate for your UI.
        }

        private void SwapDrillAttribute(BlockReference blockRef, string tag, string newValue, Database db, Transaction tr)
        {
            foreach (ObjectId attId in blockRef.AttributeCollection)
            {
                AttributeReference attRef = null;
                try
                {
                    attRef = tr.GetObject(attId, OpenMode.ForWrite) as AttributeReference;
                }
                catch (Autodesk.AutoCAD.Runtime.Exception ex) when (ex.ErrorStatus == ErrorStatus.OnLockedLayer)
                {
                    attRef = db.TransactionManager.GetObject(attId, OpenMode.ForWrite, false, true) as AttributeReference;
                }
                catch (Autodesk.AutoCAD.Runtime.Exception ex) when (ex.ErrorStatus == ErrorStatus.WasErased)
                {
                    // Skip attributes that have been erased
                    continue;
                }

                if (attRef != null && !attRef.IsErased && attRef.Tag.Equals(tag, StringComparison.OrdinalIgnoreCase))
                {
                    attRef.TextString = newValue;
                }
            }
        }

        private void CheckButton_Click(object sender, EventArgs e)
        {
            try
            {
                Document doc = AcApplication.DocumentManager.MdiActiveDocument;
                Editor ed = doc.Editor;
                Database db = doc.Database;

                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    PromptEntityOptions peo = new PromptEntityOptions("\nSelect the data-linked table:");
                    peo.SetRejectMessage("\nOnly table entities are allowed.");
                    peo.AddAllowedClass(typeof(Table), true);

                    PromptEntityResult per = ed.GetEntity(peo);
                    if (per.Status != PromptStatus.OK)
                    {
                        ed.WriteMessage("\nTable selection cancelled.");
                        return;
                    }

                    Table table = tr.GetObject(per.ObjectId, OpenMode.ForRead) as Table;
                    if (table == null)
                    {
                        ed.WriteMessage("\nSelected entity is not a table.");
                        return;
                    }

                    List<string> tableValues = ExtractTableValues(table);
                    tr.Commit();

                    List<BlockAttributeData> blockDataList = SelectAndExtractBlockData();

                    if (blockDataList == null || blockDataList.Count == 0)
                    {
                        MessageBox.Show("No blocks selected or no blocks with 'DRILLNAME' attribute found.", "Check Results", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    CompareDrillNamesWithTableAndBlocks(tableValues, blockDataList);
                }
            }
            catch (System.Exception ex)
            {
                _log.Error($"Error during check operation: {ex.Message}", ex);
                MessageBox.Show($"An error occurred during the check operation: {ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private Point3d GetCellNWCorner(Table table, int row, int col)
        {
            double baseX = table.Position.X;
            double baseY = table.Position.Y;
            double xOffset = baseX;
            for (int i = 0; i < col; i++)
                xOffset += table.Columns[i].Width;
            double yOffset = baseY;
            for (int i = 0; i < row; i++)
                yOffset -= table.Rows[i].Height;
            return new Point3d(xOffset, yOffset, 0.0);
        }

        private string ShowInputDialog(string prompt, string title, string defaultValue = "")
        {
            using (Form promptForm = new Form())
            {
                promptForm.Width = 300;
                promptForm.Height = 150;
                promptForm.Text = title;
                promptForm.BackColor = System.Drawing.Color.Black;
                promptForm.ForeColor = System.Drawing.Color.White;
                Label textLabel = new Label() { Left = 10, Top = 20, Text = prompt, AutoSize = true };
                textLabel.ForeColor = System.Drawing.Color.White;
                TextBox inputBox = new TextBox() { Left = 10, Top = 50, Width = 260 };
                inputBox.Text = defaultValue;
                Button okButton = new Button() { Text = "OK", Left = 200, Width = 70, Top = 80 };
                okButton.DialogResult = DialogResult.OK;
                promptForm.Controls.Add(textLabel);
                promptForm.Controls.Add(inputBox);
                promptForm.Controls.Add(okButton);
                promptForm.AcceptButton = okButton;
                return promptForm.ShowDialog() == DialogResult.OK ? inputBox.Text : null;
            }
        }

        private string[,] ReadExcelData(string excelFilePath, string range)
        {
            SetEpplusLicense();
            using (var package = new ExcelPackage(new FileInfo(excelFilePath)))
            {
                var ws = package.Workbook.Worksheets.First();
                var addr = new ExcelAddress(range);
                int rows = addr.Rows;
                int cols = addr.Columns;
                string[,] data = new string[rows, cols];
                for (int r = 0; r < rows; r++)
                {
                    for (int c = 0; c < cols; c++)
                    {
                        string cellValue = ws.Cells[addr.Start.Row + r, addr.Start.Column + c].Text;
                        data[r, c] = cellValue;
                    }
                }
                return data;
            }
        }

        private void InsertAndFormatTable(Point3d insertionPoint, string[,] cellData, string tableStyleName)
        {
            Document doc = AcApplication.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                BlockTableRecord btr = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);

                int rows = cellData.GetLength(0);
                int cols = cellData.GetLength(1);

                double[] columnWidths;
                if (cols == 12)
                {
                    columnWidths = new double[]
                    {
                        100.0, 100.0, 60.0, 60.0,
                        80.0, 80.0, 80.0, 80.0,
                        80.0, 80.0, 80.0, 80.0
                    };
                }
                else
                {
                    columnWidths = new double[cols];
                    for (int i = 0; i < cols; i++)
                        columnWidths[i] = 80.0;
                }

                Table table = new Table();
                table.TableStyle = GetTableStyleId(db, tableStyleName, tr);
                table.SetSize(rows, cols);
                table.Position = insertionPoint;
                table.Layer = "CG-NOTES";

                double defaultRowHeight = 25.0;
                double emptyCellRowHeight = 125.0;
                for (int r = 0; r < rows; r++)
                {
                    bool hasEmpty = false;
                    for (int c = 0; c < cols; c++)
                    {
                        string val = cellData[r, c];
                        table.Cells[r, c].TextString = val;
                        if (string.IsNullOrWhiteSpace(val))
                            hasEmpty = true;
                    }
                    table.Rows[r].Height = hasEmpty ? emptyCellRowHeight : defaultRowHeight;
                }

                for (int c = 0; c < cols; c++)
                    table.Columns[c].Width = columnWidths[c];

                btr.AppendEntity(table);
                tr.AddNewlyCreatedDBObject(table, true);

                table.GenerateLayout();
                UnmergeAllCells(table);
                table.GenerateLayout();
                RemoveAllCellBorders(table);
                AddBordersForDataCells(table);
                table.RecomputeTableBlock(true);

                tr.Commit();
            }
        }

        private ObjectId GetTableStyleId(Database db, string styleName, Transaction tr)
        {
            DBDictionary tableStyleDict = (DBDictionary)tr.GetObject(db.TableStyleDictionaryId, OpenMode.ForRead);
            foreach (var entry in tableStyleDict)
            {
                if (entry.Key.Equals(styleName, StringComparison.OrdinalIgnoreCase))
                    return entry.Value;
            }
            return ObjectId.Null;
        }

        private void UnmergeAllCells(Table table)
        {
            for (int r = 0; r < table.Rows.Count; r++)
            {
                for (int c = 0; c < table.Columns.Count; c++)
                {
                    var range = table.Cells[r, c].GetMergeRange();
                    if (range != null && range.TopRow == r && range.LeftColumn == c)
                        table.UnmergeCells(range);
                }
            }
        }

        private void RemoveAllCellBorders(Table table)
        {
            for (int r = 0; r < table.Rows.Count; r++)
            {
                for (int c = 0; c < table.Columns.Count; c++)
                {
                    Cell cell = table.Cells[r, c];
                    cell.Borders.Top.IsVisible = false;
                    cell.Borders.Bottom.IsVisible = false;
                    cell.Borders.Left.IsVisible = false;
                    cell.Borders.Right.IsVisible = false;
                }
            }
        }

        private void AddBordersForDataCells(Table table)
        {
            Autodesk.AutoCAD.Colors.Color borderColor = Autodesk.AutoCAD.Colors.Color.FromColorIndex(Autodesk.AutoCAD.Colors.ColorMethod.ByAci, 7);
            for (int r = 0; r < table.Rows.Count; r++)
            {
                for (int c = 0; c < table.Columns.Count; c++)
                {
                    Cell cell = table.Cells[r, c];
                    string val = cell.TextString;
                    bool hasData = !string.IsNullOrWhiteSpace(val);
                    if (hasData)
                    {
                        SetCellBorders(cell, true, borderColor);
                    }
                    else
                    {
                        bool topHasData = r > 0 && !string.IsNullOrWhiteSpace(table.Cells[r - 1, c].TextString);
                        bool bottomHasData = (r < table.Rows.Count - 1) && !string.IsNullOrWhiteSpace(table.Cells[r + 1, c].TextString);
                        bool leftHasData = c > 0 && !string.IsNullOrWhiteSpace(table.Cells[r, c - 1].TextString);
                        bool rightHasData = (c < table.Columns.Count - 1) && !string.IsNullOrWhiteSpace(table.Cells[r, c + 1].TextString);
                        cell.Borders.Top.IsVisible = topHasData;
                        cell.Borders.Bottom.IsVisible = bottomHasData;
                        cell.Borders.Left.IsVisible = leftHasData;
                        cell.Borders.Right.IsVisible = rightHasData;
                    }
                }
            }
        }

        private void SetCellBorders(Cell cell, bool isVisible, Autodesk.AutoCAD.Colors.Color color)
        {
            cell.Borders.Top.IsVisible = isVisible;
            cell.Borders.Bottom.IsVisible = isVisible;
            cell.Borders.Left.IsVisible = isVisible;
            cell.Borders.Right.IsVisible = isVisible;
            if (isVisible)
            {
                cell.Borders.Top.LineWeight = LineWeight.LineWeight025;
                cell.Borders.Bottom.LineWeight = LineWeight.LineWeight025;
                cell.Borders.Left.LineWeight = LineWeight.LineWeight025;
                cell.Borders.Right.LineWeight = LineWeight.LineWeight025;
                cell.Borders.Top.Color = color;
                cell.Borders.Bottom.Color = color;
                cell.Borders.Left.Color = color;
                cell.Borders.Right.Color = color;
            }
        }

        private List<string> ExtractTableValues(Table table)
        {
            List<string> tableValues = new List<string>();
            for (int row = 0; row < table.Rows.Count; row++)
            {
                string columnAValue = table.Cells[row, 0].TextString.Trim();
                string normalizedColumnAValue = columnAValue.ToUpper().Replace(" ", "");
                if (normalizedColumnAValue.Contains("BOTTOMHOLE"))
                {
                    string columnBValue = table.Cells[row, 1].TextString.Trim();
                    tableValues.Add(columnBValue);
                }
            }
            if (tableValues.Count == 0)
            {
                MessageBox.Show("No 'BOTTOM HOLE' entries found in the selected table.", "Check Results", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            return tableValues;
        }

        private List<BlockAttributeData> SelectAndExtractBlockData()
        {
            try
            {
                Document doc = AcApplication.DocumentManager.MdiActiveDocument;
                Editor ed = doc.Editor;
                Database db = doc.Database;

                PromptSelectionOptions pso = new PromptSelectionOptions { MessageForAdding = "\nSelect blocks with 'DRILLNAME' attribute:" };
                pso.AllowDuplicates = false;

                SelectionFilter filter = new SelectionFilter(new TypedValue[] { new TypedValue((int)DxfCode.Start, "INSERT") });

                PromptSelectionResult psr = ed.GetSelection(pso, filter);

                if (psr.Status != PromptStatus.OK)
                    return null;

                SelectionSet ss = psr.Value;
                List<BlockAttributeData> blockDataList = new List<BlockAttributeData>();

                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    foreach (SelectedObject selObj in ss)
                    {
                        if (selObj != null)
                        {
                            BlockReference blockRef = tr.GetObject(selObj.ObjectId, OpenMode.ForRead) as BlockReference;
                            if (blockRef != null)
                            {
                                string drillNameAttribute = GetAttributeValue(blockRef, "DRILLNAME", tr);
                                if (!string.IsNullOrEmpty(drillNameAttribute))
                                {
                                    double yCoord = blockRef.Position.Y;
                                    blockDataList.Add(new BlockAttributeData { BlockReference = blockRef, DrillName = drillNameAttribute, YCoordinate = yCoord });
                                }
                            }
                        }
                    }
                    tr.Commit();
                }

                return blockDataList;
            }
            catch (System.Exception ex)
            {
                _log.Error($"Error in SelectAndExtractBlockData: {ex.Message}", ex);
                return null;
            }
        }

        private string GetAttributeValue(BlockReference blockRef, string attributeTag, Transaction tr)
        {
            foreach (ObjectId attId in blockRef.AttributeCollection)
            {
                AttributeReference attRef = tr.GetObject(attId, OpenMode.ForRead) as AttributeReference;
                if (attRef != null && attRef.Tag.Equals(attributeTag, StringComparison.OrdinalIgnoreCase))
                {
                    return attRef.TextString.Trim();
                }
            }
            return string.Empty;
        }

        private void CompareDrillNamesWithTableAndBlocks(List<string> tableValues, List<BlockAttributeData> blockDataList)
        {
            blockDataList.Sort((a, b) => b.YCoordinate.CompareTo(a.YCoordinate));

            int comparisons = Math.Min(Math.Min(tableValues.Count, DrillCount), blockDataList.Count);
            List<string> discrepancies = new List<string>();
            List<string> reportLines = new List<string>();

            for (int i = 0; i < comparisons; i++)
            {
                string tableValue = tableValues[i];
                string drillName = GetTextBox(i)?.Text.Trim() ?? string.Empty;
                BlockAttributeData blockData = blockDataList[i];
                string blockDrillName = blockData.DrillName;

                string normalizedDrillName = DrillParsers.NormalizeDrillName(drillName);
                string normalizedTableValue = DrillParsers.NormalizeTableValue(tableValue);
                string normalizedBlockDrillName = DrillParsers.NormalizeDrillName(blockDrillName);

                bool discrepancyFound = false;
                List<string> drillDiscrepancies = new List<string>();

                if (!string.Equals(normalizedDrillName, normalizedTableValue, StringComparison.OrdinalIgnoreCase))
                {
                    drillDiscrepancies.Add("Drill name does not match table value.");
                    discrepancyFound = true;
                }

                if (!string.Equals(normalizedBlockDrillName, normalizedDrillName, StringComparison.OrdinalIgnoreCase))
                {
                    drillDiscrepancies.Add("Block DRILLNAME does not match drill name.");
                    discrepancyFound = true;
                }

                if (!string.Equals(normalizedBlockDrillName, normalizedTableValue, StringComparison.OrdinalIgnoreCase))
                {
                    drillDiscrepancies.Add("Block DRILLNAME does not match table value.");
                    discrepancyFound = true;
                }

                reportLines.Add($"DRILL_{i + 1} NAME: {drillName}");
                reportLines.Add($"TABLE RESULT: {tableValue}");
                reportLines.Add($"BLOCK DRILLNAME: {blockDrillName}");
                reportLines.Add($"Normalized Drill Name: {normalizedDrillName}");
                reportLines.Add($"Normalized Table Value: {normalizedTableValue}");
                reportLines.Add($"Normalized Block DrillName: {normalizedBlockDrillName}");

                string status = discrepancyFound ? "FAIL" : "PASS";
                reportLines.Add($"STATUS: {status}");

                if (discrepancyFound)
                {
                    reportLines.Add("Discrepancies:");
                    foreach (var disc in drillDiscrepancies)
                        reportLines.Add($"- {disc}");
                    discrepancies.Add($"DRILL_{i + 1}: {string.Join("; ", drillDiscrepancies)}");
                    var tbCheck = GetTextBox(i);
                    if (tbCheck != null)
                        HighlightTextbox(tbCheck, true);
                }
                else
                {
                    var tbCheck = GetTextBox(i);
                    if (tbCheck != null)
                        HighlightTextbox(tbCheck, false);
                }

                reportLines.Add("");
            }

            string reportFilePath = GetReportFilePath();
            try
            {
                File.WriteAllLines(reportFilePath, reportLines);
            }
            catch (System.Exception ex)
            {
                _log.Error($"Error writing report file: {ex.Message}", ex);
                MessageBox.Show($"An error occurred while writing the report file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (discrepancies.Count > 0)
            {
                string message = "Discrepancies found:\n" + string.Join("\n", discrepancies);
                MessageBox.Show($"{message}\n\nDetailed report saved at:\n{reportFilePath}", "Check Results", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show($"All drill names match the table values and block DRILLNAME attributes.\n\nDetailed report saved at:\n{reportFilePath}", "Check Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void HighlightTextbox(TextBox textbox, bool highlight)
        {
            textbox.BackColor = highlight ? Color.LightCoral : Color.LightGreen;
        }

        private string DrillCsvPipeline()
        {
            var doc = AcApplication.DocumentManager.MdiActiveDocument;
            var db = doc.Database;

            if (!LayerExists(db, "Z-DRILL-POINT"))
            {
                ShowAlert("Layer 'Z-DRILL-POINT' not found.");
                return null;
            }

            var gridData = new List<(string Label, double Northing, double Easting)>();
            using (var tr = db.TransactionManager.StartTransaction())
            {
                var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                var ms = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForRead);
                foreach (ObjectId id in ms)
                {
                    if (tr.GetObject(id, OpenMode.ForRead) is Entity ent &&
                        ent.Layer.Equals("Z-DRILL-POINT", StringComparison.OrdinalIgnoreCase))
                    {
                        if (ent is DBText dbText && IsGridLabel(dbText.TextString.Trim()))
                            gridData.Add((dbText.TextString.Trim(), dbText.Position.Y, dbText.Position.X));
                        else if (ent is MText mText && IsGridLabel(mText.Contents.Trim()))
                            gridData.Add((mText.Contents.Trim(), mText.Location.Y, mText.Location.X));
                    }
                }
                tr.Commit();
            }

            // use the NaturalStringComparer so numeric portions of labels are sorted by their value
            gridData = gridData.OrderBy(x => x.Label, new NaturalStringComparer()).ToList();

            var cordsDir = @"C:\CORDS";
            Directory.CreateDirectory(cordsDir);
            var csvPath = Path.Combine(cordsDir, "cords.csv");
            using (var sw = new StreamWriter(csvPath, false))
            {
                sw.WriteLine("Label,Northing,Easting");
                foreach (var pt in gridData)
                    sw.WriteLine($"{pt.Label},{pt.Northing},{pt.Easting}");
            }

            ShowAlert("DONT TOUCH, WAIT FOR INSTRUCTION");
            return csvPath;
        }

        private string RunCordsExe(string csvPath)
        {
            var headingValue = headingComboBox.SelectedItem?.ToString() ?? "ICP";
            var paramValue = headingValue;

            var processExe = @"C:\AUTOCAD-SETUP\Lisp_2000\Drill Properties\cords.exe";
            if (File.Exists(processExe))
            {
                _log.Info($"Running: {processExe} \"{csvPath}\" \"{paramValue}\"");
                var psi = new ProcessStartInfo(processExe, $"\"{csvPath}\" \"{paramValue}\"")
                {
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    StandardOutputEncoding = Encoding.GetEncoding(1252),
                    StandardErrorEncoding = Encoding.GetEncoding(1252)
                };
                using (var proc = Process.Start(psi))
                {
                    if (!proc.WaitForExit(180_000))
                    {
                        try { proc.Kill(); } catch { }
                        _log.Error("cords.exe timeout");
                        ShowAlert("cords.exe did not exit in time.");
                        return null;
                    }
                    var outp = proc.StandardOutput.ReadToEnd();
                    var errp = proc.StandardError.ReadToEnd();
                    if (!string.IsNullOrEmpty(outp)) _log.Info(outp);
                    if (!string.IsNullOrEmpty(errp)) _log.Error(errp);
                    if (proc.ExitCode != 0)
                    {
                        _log.Error($"cords.exe code {proc.ExitCode}");
                        ShowAlert($"cords.exe exited with {proc.ExitCode}");
                        return null;
                    }
                }
            }
            else
            {
                _log.Warn("cords.exe not found, skipping.");
            }

            var excelFilePath = Path.Combine(Path.GetDirectoryName(csvPath), "ExportedCoordsFormatted.xlsx");
            if (!File.Exists(excelFilePath))
            {
                ShowAlert("ExportedCoordsFormatted.xlsx not found.");
                return null;
            }

            return excelFilePath;
        }

        private string[,] ReadExcel(string excelFilePath)
        {
            using (var package = new ExcelPackage(new FileInfo(excelFilePath)))
            {
                var ws = package.Workbook.Worksheets.First();

                var dim = GetWorksheetDimension(ws);
                if (dim == null)
                {
                    ShowAlert("The Excel file is empty.");
                    return null;
                }

                int sr = dim.Value.startRow, sc = dim.Value.startCol;
                int er = dim.Value.endRow, ec = dim.Value.endCol;

                int lastRow = er;
                for (int r = er; r >= sr; r--)
                {
                    var blank = true;
                    for (int c = sc; c <= ec; c++)
                        if (!string.IsNullOrWhiteSpace(ws.Cells[r, c].Text))
                        {
                            blank = false;
                            break;
                        }
                    if (!blank) { lastRow = r; break; }
                }

                int rows = lastRow - sr + 1, cols = ec - sc + 1;
                var tableData = new string[rows, cols];
                for (int r = 0; r < rows; r++)
                    for (int c = 0; c < cols; c++)
                        tableData[r, c] = ws.Cells[r + sr, c + sc].Text;

                return tableData;
            }
        }

        private static (int startRow, int startCol, int endRow, int endCol)? GetWorksheetDimension(object worksheet)
        {
            if (worksheet == null) return null;

            var prop = worksheet.GetType().GetProperty("Dimension");
            if (prop == null) return null;

            var dim = prop.GetValue(worksheet);
            if (dim == null) return null;

            try
            {
                dynamic d = dim;
                return ((int)d.Start.Row, (int)d.Start.Column, (int)d.End.Row, (int)d.End.Column);
            }
            catch
            {
                var srProp = dim.GetType().GetProperty("StartRow");
                var scProp = dim.GetType().GetProperty("StartColumn");
                var erProp = dim.GetType().GetProperty("EndRow");
                var ecProp = dim.GetType().GetProperty("EndColumn");

                if (srProp != null && scProp != null && erProp != null && ecProp != null)
                {
                    int sr = (int)srProp.GetValue(dim);
                    int sc = (int)scProp.GetValue(dim);
                    int er = (int)erProp.GetValue(dim);
                    int ec = (int)ecProp.GetValue(dim);
                    return (sr, sc, er, ec);
                }
            }

            return null;
        }

        private void AdjustTableForClient(string[,] tableData, string headingValue)
        {
            if (headingValue == "HEEL")
            {
                for (int r = 0; r < tableData.GetLength(0); r++)
                    for (int c = 0; c < tableData.GetLength(1); c++)
                        if (!string.IsNullOrEmpty(tableData[r, c]) && tableData[r, c].Contains("ICP"))
                            tableData[r, c] = tableData[r, c].Replace("ICP", "HEEL");
            }
            else if (headingValue == "ICP")
            {
                for (int r = 0; r < tableData.GetLength(0); r++)
                    for (int c = 0; c < tableData.GetLength(1); c++)
                        if (!string.IsNullOrEmpty(tableData[r, c]) && tableData[r, c].Contains("HEEL"))
                            tableData[r, c] = tableData[r, c].Replace("HEEL", "ICP");
            }

            // Robust grouping by grid letter (A1, B2, etc.) to assign SURFACE,
            // BOTTOM HOLE, ICP/HEEL and TURN rows similar to the Excel macro.
            var groups = new Dictionary<char, List<int>>();
            Regex tagRx = new Regex("^[A-Z][0-9]+$", RegexOptions.IgnoreCase);

            for (int r = 0; r < tableData.GetLength(0); r++)
            {
                char? letter = null;
                for (int c = 0; c < tableData.GetLength(1); c++)
                {
                    string val = tableData[r, c];
                    if (string.IsNullOrWhiteSpace(val)) continue;
                    var s = val.Trim().ToUpper();
                    if (tagRx.IsMatch(s))
                    {
                        letter = s[0];
                        break;
                    }
                }
                if (letter.HasValue)
                {
                    if (!groups.TryGetValue(letter.Value, out var list))
                        list = groups[letter.Value] = new List<int>();
                    list.Add(r);
                }
            }

            foreach (var kv in groups)
            {
                var rows = kv.Value;
                int cnt = rows.Count;
                if (cnt == 1)
                {
                    tableData[rows[0], 0] = "SURFACE";
                }
                else
                {
                    tableData[rows[0], 0] = "SURFACE";
                    tableData[rows[cnt - 1], 0] = "BOTTOM HOLE";
                    if (cnt >= 2)
                        tableData[rows[1], 0] = headingValue;
                    for (int i = 2; i < cnt - 1; i++)
                        tableData[rows[i], 0] = $"TURN #{i - 1}";
                }
            }

            // Fallback: if entire table has only one row and it's marked as
            // BOTTOM HOLE, convert to SURFACE.
            int nonEmptyRows = 0;
            for (int r = 0; r < tableData.GetLength(0); r++)
            {
                bool hasData = false;
                for (int c = 0; c < tableData.GetLength(1); c++)
                {
                    if (!string.IsNullOrWhiteSpace(tableData[r, c]))
                    {
                        hasData = true;
                        break;
                    }
                }
                if (hasData)
                    nonEmptyRows++;
            }

            if (nonEmptyRows == 1)
            {
                string cellValue = tableData[0, 0] ?? string.Empty;
                string normalized = cellValue.ToUpper().Replace(" ", "");
                if (normalized.Contains("BOTTOMHOLE"))
                    tableData[0, 0] = "SURFACE";
            }

            // Additional fallback: if column A contains "BOTTOM HOLE" but no
            // "SURFACE" anywhere, convert all such entries to "SURFACE".
            bool colAHasSurface = false;
            var bottomHoleRows = new List<int>();
            for (int r = 0; r < tableData.GetLength(0); r++)
            {
                string val = tableData[r, 0] ?? string.Empty;
                string norm = val.ToUpper().Replace(" ", "");
                if (norm.Contains("SURFACE"))
                {
                    colAHasSurface = true;
                    break;
                }
                if (norm.Contains("BOTTOMHOLE"))
                    bottomHoleRows.Add(r);
            }

            if (!colAHasSurface)
            {
                foreach (int r in bottomHoleRows)
                    tableData[r, 0] = "SURFACE";
            }
        }

        private bool InsertTablePipeline(string[,] tableData)
        {
            var doc = AcApplication.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;

            ShowAlert("BACK TO CAD, PICK A POINT");
            var ppr = ed.GetPoint("\nSelect insertion point:");
            if (ppr.Status != PromptStatus.OK)
            {
                ed.WriteMessage("\nCancelled.");
                return false;
            }
            var insertionPt = ppr.Value;

            using (var docLock = doc.LockDocument())
            {
                var db = doc.Database;
                var layerSvc = new LayerService();
                layerSvc.EnsureLayer(db, "CG-NOTES");
                InsertAndFormatTable(insertionPt, tableData, "induction Bend");
            }

            return true;
        }

        private bool IsGridLabel(string text)
        {
            return Regex.IsMatch(text?.Trim() ?? string.Empty,
                                 "^[A-Z][0-9]{1,3}$",
                                 RegexOptions.IgnoreCase);
        }

        private static IEnumerable<Entity> GetEntitiesOnLayer(Database db, string layer, params RXClass[] types)
        {
            var results = new List<Entity>();
            if (db == null || string.IsNullOrEmpty(layer))
                return results;

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                BlockTableRecord ms = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForRead);
                foreach (ObjectId id in ms)
                {
                    Entity ent = tr.GetObject(id, OpenMode.ForRead) as Entity;
                    if (ent == null) continue;
                    if (!ent.Layer.Equals(layer, StringComparison.OrdinalIgnoreCase)) continue;

                    if (types != null && types.Length > 0)
                    {
                        bool match = false;
                        var rx = ent.GetRXClass();
                        foreach (var cls in types)
                        {
                            if (rx.IsDerivedFrom(cls)) { match = true; break; }
                        }
                        if (!match) continue;
                    }

                    results.Add(ent.Clone() as Entity);
                }
                tr.Commit();
            }

            return results;
        }

        private bool LayerExists(Database db, string name)
        {
            if (db == null || string.IsNullOrEmpty(name)) return false;
            using (var tr = db.TransactionManager.StartTransaction())
            {
                var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
                var exists = lt.Has(name);
                tr.Commit();
                return exists;
            }
        }

        private void ShowAlert(string msg) =>
            AcApplication.ShowAlertDialog(msg);

        private string GetReportFilePath()
        {
            Document acDoc = AcApplication.DocumentManager.MdiActiveDocument;
            if (acDoc == null || string.IsNullOrEmpty(acDoc.Name))
            {
                throw new InvalidOperationException("No active AutoCAD document found.");
            }
            string dwgDirectory = Path.GetDirectoryName(acDoc.Name);
            string drawingName = Path.GetFileNameWithoutExtension(acDoc.Name);
            string reportFilePath = Path.Combine(dwgDirectory, $"{drawingName}_CheckReport.txt");
            return reportFilePath;
        }

        private void SetUiLocked(bool locked)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action(() => SetUiLocked(locked)));
                return;
            }

            if (_lockOverlay == null)
            {
                _lockOverlay = new Panel
                {
                    Dock = DockStyle.Fill,
                    BackColor = Color.FromArgb(180, Color.Gray),
                    Visible = false
                };
                var lbl = new Label
                {
                    Dock = DockStyle.Fill,
                    TextAlign = ContentAlignment.MiddleCenter,
                    Font = new System.Drawing.Font("Segoe UI", 10, FontStyle.Bold),
                    ForeColor = Color.White
                };
                _lockOverlay.Controls.Add(lbl);
                Controls.Add(_lockOverlay);
                _lockOverlay.BringToFront();
            }

            if (_lockOverlay.Controls.Count > 0 && _lockOverlay.Controls[0] is Label l)
            {
                l.Text = $"This dialog belongs to:\n{System.IO.Path.GetFileName(_boundDoc?.Name)}\n\nActivate that drawing to re-enable the controls.";
            }

            _lockOverlay.Visible = locked;

            foreach (Control ctl in Controls)
            {
                if (ctl == _lockOverlay) continue;
                ctl.Enabled = !locked;
            }
        }

        private void HideLockOverlay()
        {
            if (_lockOverlay != null)
                _lockOverlay.Visible = false;
        }
    }
}
