using System.IO;
using Newtonsoft.Json;
using DrillNamer.UI.Models;

namespace DrillNamer.UI.Services
{
    public class JsonSettingsService
    {
        private readonly AppSettings _app;
        public JsonSettingsService(AppSettings app)
        {
            _app = app;
        }

        private string GetPath()
        {
            var doc = Autodesk.AutoCAD.ApplicationServices.Application
                .DocumentManager.MdiActiveDocument;

            if (doc != null && !string.IsNullOrEmpty(doc.Name))
            {
                var dir = Path.GetDirectoryName(doc.Name);
                var drawingName = Path.GetFileNameWithoutExtension(doc.Name);

                drawingName = drawingName.TrimEnd('-');
                var parts = drawingName.Split('-');
                var prefix = parts.Length >= 2 ? $"{parts[0]}-{parts[1]}" : drawingName;
                return Path.Combine(dir, $"{prefix}.json");
            }

            return Path.Combine(Directory.GetCurrentDirectory(), _app.JsonConfigName);
        }

        public void Save(DrillGridState state)
        {
            var path = GetPath();
            File.WriteAllText(path, JsonConvert.SerializeObject(state, Formatting.Indented));
        }

        public DrillGridState Load(int drillCount)
        {
            var path = GetPath();
            if (!File.Exists(path))
                return DrillGridState.CreateDefault(drillCount);
            var json = File.ReadAllText(path);
            return JsonConvert.DeserializeObject<DrillGridState>(json);
        }
    }
}
