using Autodesk.AutoCAD.DatabaseServices;
using DrillNamer.UI.Infrastructure;

namespace DrillNamer.UI.Services
{
    public class LayerService
    {
        public void EnsureLayer(Database db, string layerName)
        {
            AcadContext.Run(db, true, tr =>
            {
                var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
                if (!lt.Has(layerName))
                {
                    lt.UpgradeOpen();
                    var ltr = new LayerTableRecord { Name = layerName };
                    lt.Add(ltr);
                    tr.AddNewlyCreatedDBObject(ltr, true);
                }
            });
        }
    }
}
