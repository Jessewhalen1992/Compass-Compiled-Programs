using System;
using System.Reflection;
using OfficeOpenXml;
using NLog;

namespace DrillNamer.UI.Services
{
    public static partial class EpplusCompat
    {
        private static readonly Logger Log = LogManager.GetCurrentClassLogger();

        public static void EnsureLicense()
        {
            try
            {
                var pkgType = typeof(ExcelPackage);
                var asm = pkgType.Assembly;

                var licenseContainerType = asm.GetType("OfficeOpenXml.ExcelPackageLicenseContext")
                                         ?? asm.GetType("OfficeOpenXml.LicenseContext");
                if (licenseContainerType != null)
                {
                    var licProp = pkgType.GetProperty("License", BindingFlags.Static | BindingFlags.Public);
                    if (licProp != null)
                    {
                        var licObj = licProp.GetValue(null);
                        var setMeth = licObj?.GetType().GetMethod("SetLicense", new[] { licenseContainerType });
                        if (setMeth != null)
                        {
                            var nonComm = Enum.Parse(licenseContainerType, "NonCommercial");
                            setMeth.Invoke(licObj, new[] { nonComm });
                            return;
                        }
                    }
                }

                var ctxProp = pkgType.GetProperty("LicenseContext", BindingFlags.Static | BindingFlags.Public);
                if (ctxProp != null)
                {
                    var nonComm = Enum.Parse(ctxProp.PropertyType, "NonCommercial");
                    ctxProp.SetValue(null, nonComm);
                    return;
                }
            }
            catch (Exception ex)
            {
                Log.Warn(ex, "Failed to set EPPlus license context");
            }
        }
    }
}
