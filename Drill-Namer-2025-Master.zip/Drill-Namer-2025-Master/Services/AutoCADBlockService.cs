using System;
using System.Collections.Generic;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using DrillNamer.UI.Infrastructure;

namespace DrillNamer.UI.Services
{
    public class AutoCADBlockService
    {
        public string GetAttributeValue(BlockReference blockRef, string tag, Transaction tr)
        {
            foreach (ObjectId attId in blockRef.AttributeCollection)
            {
                var attRef = tr.GetObject(attId, OpenMode.ForRead) as AttributeReference;
                if (attRef != null && attRef.Tag.Equals(tag, StringComparison.OrdinalIgnoreCase))
                    return attRef.TextString.Trim();
            }
            return string.Empty;
        }

        public void SwapAttribute(BlockReference blockRef, string tag, string newValue, Transaction tr)
        {
            foreach (ObjectId attId in blockRef.AttributeCollection)
            {
                var attRef = tr.GetObject(attId, OpenMode.ForWrite) as AttributeReference;
                if (attRef != null && attRef.Tag.Equals(tag, StringComparison.OrdinalIgnoreCase))
                    attRef.TextString = newValue;
            }
        }

        public List<BlockReference> GetBlocksOnLayer(Database db, string layer)
        {
            return AcadContext.Run(db, false, tr =>
            {
                var results = new List<BlockReference>();
                BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                BlockTableRecord ms = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForRead);
                foreach (ObjectId id in ms)
                {
                    var blk = tr.GetObject(id, OpenMode.ForRead) as BlockReference;
                    if (blk != null && blk.Layer.Equals(layer, StringComparison.OrdinalIgnoreCase))
                        results.Add(blk);
                }
                return results;
            });
        }
    }
}
