using System;
using System.Collections.Generic;
using System.IO;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;

namespace DrillNamer.UI.Services
{
    public static class AutoCADHelper
    {
        public static Transaction StartTransaction()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            return doc.Database.TransactionManager.StartTransaction();
        }

        public static bool GetInsertionPoint(string promptMessage, out Point3d insertionPoint)
        {
            insertionPoint = Point3d.Origin;
            Document doc = Application.DocumentManager.MdiActiveDocument;
            if (doc == null) return false;

            Editor ed = doc.Editor;
            PromptPointOptions opts = new PromptPointOptions("\n" + promptMessage);
            PromptPointResult res = ed.GetPoint(opts);

            if (res.Status == PromptStatus.OK)
            {
                insertionPoint = res.Value;
                return true;
            }
            return false;
        }

        public static ObjectId InsertBlock(string blockName, Point3d insertionPoint, Dictionary<string, string> attributes, double scale = 1.0)
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            ObjectId brId = ObjectId.Null;

            using (DocumentLock docLock = doc.LockDocument())
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                if (!EnsureBlockIsLoaded(db, blockName))
                    return ObjectId.Null;

                BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                if (!bt.Has(blockName))
                    return ObjectId.Null;

                ObjectId btrId = bt[blockName];
                BlockTableRecord btr = (BlockTableRecord)tr.GetObject(btrId, OpenMode.ForRead);
                BlockTableRecord ms = (BlockTableRecord)tr.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);

                BlockReference br = new BlockReference(insertionPoint, btrId)
                {
                    ScaleFactors = new Scale3d(scale, scale, scale)
                };

                if (!CreateLayerIfMissing(db, "CG-NOTES"))
                    br.Layer = "0";
                else
                    br.Layer = "CG-NOTES";

                ms.AppendEntity(br);
                tr.AddNewlyCreatedDBObject(br, true);

                foreach (ObjectId id in btr)
                {
                    DBObject obj = tr.GetObject(id, OpenMode.ForRead);
                    if (obj is AttributeDefinition attDef)
                    {
                        AttributeReference attRef = new AttributeReference();
                        attRef.SetAttributeFromBlock(attDef, br.BlockTransform);
                        if (attributes != null && attributes.ContainsKey(attDef.Tag))
                            attRef.TextString = attributes[attDef.Tag];
                        else
                            attRef.TextString = attDef.TextString;
                        attRef.Layer = br.Layer;
                        br.AttributeCollection.AppendAttribute(attRef);
                        tr.AddNewlyCreatedDBObject(attRef, true);
                    }
                }

                tr.Commit();
                brId = br.ObjectId;
            }

            return brId;
        }

        private static bool EnsureBlockIsLoaded(Database db, string blockName)
        {
            bool exists = false;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                exists = bt.Has(blockName);
                tr.Commit();
            }
            if (exists) return true;

            string baseFolder = @"C:\AUTOCAD-SETUP\Lisp_2000\Drill Properties";
            string dwgPath = Path.Combine(baseFolder, blockName + ".dwg");
            if (!File.Exists(dwgPath))
                return false;

            return ImportBlockDefinition(db, dwgPath, blockName) != ObjectId.Null;
        }

        private static ObjectId ImportBlockDefinition(Database destDb, string sourceDwgPath, string blockName)
        {
            if (destDb == null || string.IsNullOrEmpty(sourceDwgPath) || !File.Exists(sourceDwgPath))
                return ObjectId.Null;

            ObjectId result = ObjectId.Null;
            using (Database tempDb = new Database(false, true))
            {
                try
                {
                    tempDb.ReadDwgFile(sourceDwgPath, FileShare.Read, true, "");
                    using (Transaction tr = tempDb.TransactionManager.StartTransaction())
                    {
                        BlockTable sourceBT = (BlockTable)tr.GetObject(tempDb.BlockTableId, OpenMode.ForRead);
                        if (!sourceBT.Has(blockName))
                            return ObjectId.Null;

                        ObjectId sourceBtrId = sourceBT[blockName];
                        ObjectIdCollection idsToClone = new ObjectIdCollection { sourceBtrId };
                        tr.Commit();

                        IdMapping mapping = new IdMapping();
                        destDb.WblockCloneObjects(idsToClone, destDb.BlockTableId, mapping, DuplicateRecordCloning.Replace, false);
                    }

                    using (Transaction destTr = destDb.TransactionManager.StartTransaction())
                    {
                        BlockTable destBT = (BlockTable)destTr.GetObject(destDb.BlockTableId, OpenMode.ForRead);
                        if (destBT.Has(blockName))
                            result = destBT[blockName];
                        destTr.Commit();
                    }
                }
                catch { }
            }

            return result;
        }

        private static bool CreateLayerIfMissing(Database db, string layerName)
        {
            bool success = false;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                LayerTable lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
                if (lt.Has(layerName))
                {
                    success = true;
                }
                else
                {
                    lt.UpgradeOpen();
                    LayerTableRecord ltr = new LayerTableRecord { Name = layerName };
                    lt.Add(ltr);
                    tr.AddNewlyCreatedDBObject(ltr, true);
                    success = true;
                }
                tr.Commit();
            }
            return success;
        }
    }
}
