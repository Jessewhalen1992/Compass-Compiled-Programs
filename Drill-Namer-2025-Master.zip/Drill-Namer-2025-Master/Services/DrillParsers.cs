using System.Text.RegularExpressions;

namespace DrillNamer.UI.Services
{
    public static class DrillParsers
    {
        private static readonly Regex NameRx = new Regex(@"(\d{1,2}-\d{1,2}-\d{1,3}-\d{1,2})", RegexOptions.Compiled);
        private static readonly Regex OffsetRx = new Regex(@"^\s*([+-]?\d+(\.\d+)?)\s*([NnSsEeWw])\s*$", RegexOptions.Compiled);

        public static string NormalizeDrillName(string name)
        {
            var m = NameRx.Match(name);
            if (!m.Success) return string.Empty;
            string[] parts = m.Value.Split('-');
            for (int i = 0; i < parts.Length; i++)
                parts[i] = parts[i].TrimStart('0');
            return string.Join("-", parts);
        }

        public static string NormalizeTableValue(string val)
        {
            val = Regex.Replace(val, @"\{.*?;", "");
            val = val.Replace("}", "");
            val = val.ToUpper().Replace(" ", "");
            val = Regex.Replace(val, "W\\d+", "", RegexOptions.IgnoreCase);
            string[] parts = val.Split('-');
            for (int i = 0; i < parts.Length; i++) parts[i] = parts[i].TrimStart('0');
            return string.Join("-", parts);
        }

        public static bool IsGridLabel(string text)
        {
            return Regex.IsMatch(text.Trim(), "^[A-Z][1-9][0-9]{0,2}$");
        }

        public static bool TryParseOffset(string text, out double value, out char dir)
        {
            value = 0; dir = '\0';
            var m = OffsetRx.Match(text);
            if (!m.Success) return false;
            value = double.Parse(m.Groups[1].Value);
            dir = char.ToUpperInvariant(m.Groups[3].Value[0]);
            return true;
        }
    }
}
