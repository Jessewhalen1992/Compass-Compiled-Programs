using System;
using System.Collections.Generic;

namespace DrillNamer.UI.Services
{
    /// <summary>
    /// Provides a comparer that sorts strings using natural ordering so that
    /// numeric parts are compared by value.
    /// </summary>
    public class NaturalStringComparer : IComparer<string>
    {
        public int Compare(string x, string y)
        {
            return CompareNatural(x, y);
        }

        private static int CompareNatural(string a, string b)
        {
            if (ReferenceEquals(a, b))
                return 0;
            if (a == null)
                return -1;
            if (b == null)
                return 1;

            int ia = 0, ib = 0;
            while (ia < a.Length && ib < b.Length)
            {
                char ca = a[ia];
                char cb = b[ib];
                bool da = char.IsDigit(ca);
                bool db = char.IsDigit(cb);

                if (da && db)
                {
                    long va = 0;
                    while (ia < a.Length && char.IsDigit(a[ia]))
                    {
                        va = va * 10 + (a[ia] - '0');
                        ia++;
                    }

                    long vb = 0;
                    while (ib < b.Length && char.IsDigit(b[ib]))
                    {
                        vb = vb * 10 + (b[ib] - '0');
                        ib++;
                    }

                    int numCompare = va.CompareTo(vb);
                    if (numCompare != 0)
                        return numCompare;
                }
                else
                {
                    int charCompare = char.ToUpperInvariant(ca).CompareTo(char.ToUpperInvariant(cb));
                    if (charCompare != 0)
                        return charCompare;
                    ia++;
                    ib++;
                }
            }

            if (ia < a.Length)
                return 1;
            if (ib < b.Length)
                return -1;
            return 0;
        }
    }
}
