using System.Collections.Generic;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.ApplicationServices;
using DrillNamer.UI.Infrastructure;
using DrillNamer.UI.Infrastructure.Logging;

namespace DrillNamer.UI.Services
{
    public class CoordinateTableService
    {
        private readonly ILog _log;
        public CoordinateTableService(ILog log) => _log = log;

        public List<string> GetBottomHoleValues(Table table)
        {
            var list = new List<string>();
            for (int r = 0; r < table.Rows.Count; r++)
            {
                var val = table.Cells[r, 0].TextString.Trim().ToUpper();
                if (val.Contains("BOTTOMHOLE"))
                {
                    list.Add(table.Cells[r, 1].TextString.Trim());
                }
            }
            return list;
        }

        public Table PromptForTable(string prompt)
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            PromptEntityOptions peo = new PromptEntityOptions(prompt);
            peo.SetRejectMessage("Only table entities allowed");
            peo.AddAllowedClass(typeof(Table), true);
            var res = ed.GetEntity(peo);
            if (res.Status != PromptStatus.OK) return null;
            return AcadContext.Run(doc.Database, false, tr =>
                tr.GetObject(res.ObjectId, OpenMode.ForRead) as Table);
        }
    }
}
