﻿using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using System;

namespace DrillNamer.UI
{
    /// <summary>Helpers that guarantee a valid <see cref="DocumentLock"/>
    /// and (optionally) a temporarily‑unlocked layer.</summary>
    internal static class AcadGuard
    {
        /*---------------------------------------------------------
         * Execute a WRITE action safely: we own the document lock,
         * have a started Transaction, and commit at the end.
         *--------------------------------------------------------*/
        internal static void ExecuteWrite(Action<Transaction> body)
        {
            Document doc = Application.DocumentManager.MdiActiveDocument
                              ?? throw new InvalidOperationException("No active DWG.");

            using (DocumentLock dLock = doc.LockDocument())
            using (Transaction tr = doc.Database.TransactionManager.StartTransaction())
            {
                body(tr);
                tr.Commit();
            }
        }

        /*---------------------------------------------------------
         * Thin RAII helper that unlocks a layer for the lifetime
         * of the current scope and relocks automatically.
         *--------------------------------------------------------*/
        internal readonly struct UnlockLayerScope : IDisposable
        {
            private readonly LayerTableRecord _ltr;
            private readonly bool _shouldRelock;

            internal UnlockLayerScope(LayerTableRecord ltr)
            {
                _ltr = ltr;
                _shouldRelock = ltr.IsLocked;
                if (_shouldRelock) _ltr.IsLocked = false;
            }
            public void Dispose()
            {
                if (_shouldRelock && !_ltr.IsErased) _ltr.IsLocked = true;
            }
        }

        /// <summary>
        /// Opens the given layer <paramref name="name"/> for write, returns a
        /// disposable scope object – wrap it in <c>using</c>.
        /// </summary>
        internal static UnlockLayerScope TemporarilyUnlockLayer(
            Transaction tr, Database db, string name)
        {
            LayerTable lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            if (!lt.Has(name))
                throw new Autodesk.AutoCAD.Runtime.Exception(
                        Autodesk.AutoCAD.Runtime.ErrorStatus.BadLayerName,   // or InvalidInput
                        $"Layer \"{name}\" not found.");

            LayerTableRecord ltr =
                (LayerTableRecord)tr.GetObject(lt[name], OpenMode.ForWrite);
            return new UnlockLayerScope(ltr);
        }
    }
}
