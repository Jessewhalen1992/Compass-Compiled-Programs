using System;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using DrillNamer.UI.Models;
using DrillNamer.UI.Services;
using DrillNamer.UI.Presenters;
using DrillNamer.UI.Infrastructure.Logging;

namespace DrillNamer.UI
{
    public partial class FindReplaceForm : Form
    {
        private readonly DrillGridPresenter _presenter;
        private readonly ILog _log;
        private readonly IConfiguration _config;

        public FindReplaceForm()
        {
            InitializeDynamicControls();

            // load settings
            _config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .Build();

            // The parameterless ctor is fine too, but keep the overload for later.
            var logger = new NLogLogger(_config);
            var app = _config.GetSection("AppSettings").Get<AppSettings>() ?? new AppSettings();
            _log = logger;

            var jsonSvc = new JsonSettingsService(app);
            _presenter = new DrillGridPresenter(drillTextBoxes, drillLabels, jsonSvc);
            _presenter.Load(DrillCount);

            HookDrawingActivation();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            _presenter.Save();
            Close();
        }
    }
}
