using System;
using System.Collections.Generic;
using System.Windows.Forms;
using DrillNamer.UI.Models;
using DrillNamer.UI.Services;

namespace DrillNamer.UI.Presenters
{
    public class DrillGridPresenter
    {
        private readonly TextBox[] _textBoxes;
        private readonly Label[] _labels;
        private readonly JsonSettingsService _json;
        private DrillGridState _state;

        public DrillGridPresenter(TextBox[] textBoxes, Label[] labels, JsonSettingsService json)
        {
            _textBoxes = textBoxes;
            _labels = labels;
            _json = json;
        }

        public void Load(int count)
        {
            _state = _json.Load(count);
            for (int i = 0; i < count; i++)
            {
                _textBoxes[i].Text = _state.DrillNames[i];
                _labels[i].Text = _state.DrillNames[i];
            }
        }

        public void Save()
        {
            for (int i = 0; i < _textBoxes.Length; i++)
            {
                _state.DrillNames[i] = _textBoxes[i].Text.Trim();
            }
            _json.Save(_state);
        }
    }
}
