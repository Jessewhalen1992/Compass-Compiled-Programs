using System;
using System.Text;
using NLog;

namespace DrillNamer.Infrastructure
{
    /// <summary>Runs once when the assembly is loaded – before any WinForms ctor executes.</summary>
    internal static class Bootstrap
    {
        private static readonly Logger Log = LogManager.GetCurrentClassLogger();

        static Bootstrap()
        {
            try
            {
                // Enable OEM / Windows code-pages such as 437, 850, 1252, … on .NET 5+
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            }
            catch (Exception ex)
            {
                Log.Warn(ex, "Failed to register code page provider");
            }
        }

        /// <remarks>
        /// Referencing this method anywhere forces the type loader to execute the static ctor.
        /// </remarks>
        internal static void Init() { /* nop – handled by static ctor */ }
    }
}
