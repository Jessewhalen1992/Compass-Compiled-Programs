using System;

namespace DrillNamer.UI.Infrastructure.Logging
{
    /// <summary>Slim abstraction so we can swap NLog out later.</summary>
    public interface ILog
    {
        void Info(string message);
        void Warn(string message);
        void Error(string message, Exception ex = null);
        void Debug(string message);
        /// <returns>An <see cref="IDisposable"/> that ends the scope on dispose.</returns>
        IDisposable BeginScope(string scopeMessage);
    }
}
