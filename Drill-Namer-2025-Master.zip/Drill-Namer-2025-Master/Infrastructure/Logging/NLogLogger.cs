using System;
using NLog;
using DrillNamer.UI.Infrastructure.Logging;
using Microsoft.Extensions.Configuration;

public sealed class NLogLogger : ILog
{
    private readonly Logger _log = LogManager.GetCurrentClassLogger();

    public NLogLogger() { }

    /// <summary>
    /// Optional DI-style constructor – currently we just ignore the config
    /// but having the overload fixes CS1729 and lets us use it later.
    /// </summary>
    public NLogLogger(IConfiguration _) { }

    public void Info (string msg)               => _log.Info (msg);
    public void Warn (string msg)               => _log.Warn (msg);
    public void Error(string msg, Exception ex) => _log.Error(ex, msg);
    public void Debug(string msg)               => _log.Debug(msg);

    /// <summary>Pushes a message onto NLog’s NDLC stack and returns the token.</summary>
    public IDisposable BeginScope(string scopeMessage)
        => NestedDiagnosticsLogicalContext.Push(scopeMessage);
}
