using System;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;

namespace DrillNamer.UI.Infrastructure
{
    public static class AcadContext
    {
        public static T Run<T>(Database db, bool write, Func<Transaction, T> action)
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            using (doc.LockDocument())
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                try
                {
                    T result = action(tr);
                    if (write) tr.Commit();
                    else tr.Abort();
                    return result;
                }
                catch
                {
                    tr.Abort();
                    throw;
                }
            }
        }

        public static void Run(Database db, bool write, Action<Transaction> action)
        {
            Run(db, write, tr => { action(tr); return true; });
        }
    }
}
