namespace DrillNamer.UI.Models
{
    public class AppSettings
    {
        public string BaseBlockFolder { get; set; }
        public string[] DefaultLayerNames { get; set; }
        public string JsonConfigName { get; set; } = "drillProps.json";
    }
}
