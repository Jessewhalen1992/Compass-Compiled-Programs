using Autodesk.AutoCAD.DatabaseServices;

namespace DrillNamer.UI.Models
{
    public class BlockAttributeData
    {
        public BlockReference BlockReference { get; set; }
        public string DrillName { get; set; }
        public double YCoordinate { get; set; }
    }
}
