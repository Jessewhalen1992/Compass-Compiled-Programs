using System.Collections.Generic;

namespace DrillNamer.UI.Models
{
    public class DrillGridState
    {
        public List<string> DrillNames { get; set; } = new List<string>();
        public string Heading { get; set; }

        public static DrillGridState CreateDefault(int count)
        {
            var state = new DrillGridState();
            for (int i = 0; i < count; i++)
                state.DrillNames.Add($"DRILL_{i + 1}");
            state.Heading = "ICP";
            return state;
        }
    }
}
